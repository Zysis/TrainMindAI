-- Migration: password reset
-- Rationale:
--   Aggiunge il supporto al flusso "password dimenticata" e traccia il momento
--   dell'ultimo cambio password.
--
--     - resetTokenHash:    hash SHA-256 del token di reset. Non salviamo MAI il
--                          token in chiaro: se il DB viene compromesso, i token
--                          pendenti restano inutilizzabili. UNIQUE perche' il
--                          lookup avviene per token (findUnique).
--     - resetTokenExpiry:  scadenza del link (default applicativo: 60 minuti).
--     - passwordChangedAt: utile per audit e per invalidare sessioni emesse
--                          prima del cambio.
--
--   Tutte le operazioni sono idempotenti: sicura da rieseguire su DB gia'
--   allineati (es. ambienti aggiornati via `prisma db push`).

ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "resetTokenHash"    TEXT;
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "resetTokenExpiry"  TIMESTAMP(3);
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "passwordChangedAt" TIMESTAMP(3);

-- Indice unico sul token: garantisce il findUnique e previene collisioni.
-- NULL non viola UNIQUE in PostgreSQL, quindi gli utenti senza reset pendente
-- (la grande maggioranza) convivono senza problemi.
CREATE UNIQUE INDEX IF NOT EXISTS "users_resetTokenHash_key" ON "users"("resetTokenHash");
