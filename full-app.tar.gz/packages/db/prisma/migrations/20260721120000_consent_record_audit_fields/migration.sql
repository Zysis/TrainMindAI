-- Migration: consent_records base + audit fields
-- Rationale:
--   La tabella "consent_records" era nel schema.prisma ma nessuna migrazione la
--   creava (probabilmente aggiunta via `prisma db push`). Questa migrazione:
--     1) crea la tabella se non esiste (shadow DB / nuovi ambienti);
--     2) aggiunge i campi di audit richiesti dalla proof-of-consent
--        (userAgent, language, metadata) e il ciclo revoca (revokedAt, revokeReason).
--   Tutte le operazioni sono idempotenti: sicura anche sul DB dev che ha già la
--   tabella nella forma vecchia.

-- 1) Base table -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "consent_records" (
    "id"         TEXT NOT NULL,
    "userId"     TEXT NOT NULL,
    "docType"    TEXT NOT NULL,
    "docVersion" TEXT NOT NULL,
    "acceptedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ipAddress"  TEXT,
    CONSTRAINT "consent_records_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "consent_records_userId_docType_idx"
    ON "consent_records" ("userId", "docType");

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_name = 'consent_records_userId_fkey'
          AND table_name = 'consent_records'
    ) THEN
        ALTER TABLE "consent_records"
            ADD CONSTRAINT "consent_records_userId_fkey"
            FOREIGN KEY ("userId") REFERENCES "users"("id")
            ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
END $$;

-- 2) Audit fields -----------------------------------------------------------
ALTER TABLE "consent_records" ADD COLUMN IF NOT EXISTS "userAgent"    TEXT;
ALTER TABLE "consent_records" ADD COLUMN IF NOT EXISTS "language"     TEXT;
ALTER TABLE "consent_records" ADD COLUMN IF NOT EXISTS "metadata"     JSONB;
ALTER TABLE "consent_records" ADD COLUMN IF NOT EXISTS "revokedAt"    TIMESTAMP(3);
ALTER TABLE "consent_records" ADD COLUMN IF NOT EXISTS "revokeReason" TEXT;

CREATE INDEX IF NOT EXISTS "consent_records_userId_docType_revokedAt_idx"
    ON "consent_records" ("userId", "docType", "revokedAt");
