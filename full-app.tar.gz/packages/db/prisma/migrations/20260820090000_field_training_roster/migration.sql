-- Field training: semaforo presenze per atleta + giocatori ospiti di sessione
ALTER TABLE "field_training_entries" ADD COLUMN IF NOT EXISTS "status" TEXT NOT NULL DEFAULT 'PRESENT';
ALTER TABLE "field_training_entries" ADD COLUMN IF NOT EXISTS "note" TEXT;
ALTER TABLE "field_training_sessions" ADD COLUMN IF NOT EXISTS "guests" JSONB NOT NULL DEFAULT '[]';

CREATE INDEX IF NOT EXISTS "field_training_entries_status_idx" ON "field_training_entries"("status");
