-- Aggiunge la lingua UI preferita all'utente.
-- Idempotente: puo' essere riapplicata senza errori (vedi GUIDA_AGGIORNAMENTI sez. 2).
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "locale" TEXT;
