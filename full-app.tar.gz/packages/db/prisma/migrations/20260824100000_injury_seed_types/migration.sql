-- Infortuni: i tipi scritti in chiaro dagli script di seed diventano codici.
--   Distorsione  -> ligament / traumatic
--   Stiramento   -> muscular / non_traumatic
--   Tendinopatia -> tendon   / overuse
--
-- L'insorgenza si compila solo dove è ancora vuota, così una classificazione
-- fatta a mano dopo il seed non viene sovrascritta.
-- Le sedi restano il testo libero che sono sempre state: ora la localizzazione
-- è un campo editabile, quindi è un valore legittimo.

UPDATE "injuries"
SET "type" = 'ligament', "onset" = COALESCE("onset", 'traumatic')
WHERE "type" = 'Distorsione';

UPDATE "injuries"
SET "type" = 'muscular', "onset" = COALESCE("onset", 'non_traumatic')
WHERE "type" = 'Stiramento';

UPDATE "injuries"
SET "type" = 'tendon', "onset" = COALESCE("onset", 'overuse')
WHERE "type" = 'Tendinopatia';
