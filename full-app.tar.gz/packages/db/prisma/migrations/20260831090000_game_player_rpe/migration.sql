-- RPE per singolo giocatore sulla scheda partita.
--
-- Finora la partita registrava solo i minuti: al completamento nascevano
-- TrainingSession senza `rpe`, quindi senza carico sRPE, e una partita
-- spariva dagli analytici del carico pur essendo lo stimolo piu' intenso
-- della settimana. Con questa colonna il carico si calcola come per
-- l'allenamento: sRPE = RPE x minuti giocati.
--
-- Nullable senza default: una partita gia' archiviata non ha un RPE e
-- inventarne uno falserebbe il carico storico. Chi non ha RPE continua a
-- produrre la sua riga con i soli minuti, come prima.

ALTER TABLE "game_player_entries"
  ADD COLUMN IF NOT EXISTS "rpe" INTEGER;
