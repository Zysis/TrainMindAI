-- Libreria esercizi: "Resistenza" e "Condizionamento" diventano una sola
-- categoria, "Condizionamento-Metabolico".
--
-- Cambia solo la colonna `category`: nessun esercizio viene creato o eliminato.
-- Per tornare indietro servirebbe sapere quale dei due valori aveva ciascuna
-- riga, informazione che la fusione perde: fare il backup prima.

UPDATE "exercises"
SET "category" = 'Condizionamento-Metabolico'
WHERE "category" IN ('Resistenza', 'Condizionamento');
