-- CreateTable
CREATE TABLE "field_training_sessions" (
    "id" TEXT NOT NULL,
    "calendarEventId" TEXT NOT NULL,
    "teamId" TEXT,
    "organizationId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'IN_PROGRESS',
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "field_training_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "field_training_entries" (
    "id" TEXT NOT NULL,
    "fieldTrainingSessionId" TEXT NOT NULL,
    "athleteId" TEXT NOT NULL,
    "totalActiveMs" INTEGER NOT NULL DEFAULT 0,
    "laps" JSONB NOT NULL DEFAULT '[]',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "field_training_entries_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "field_training_sessions_calendarEventId_key" ON "field_training_sessions"("calendarEventId");

-- CreateIndex
CREATE INDEX "field_training_sessions_organizationId_idx" ON "field_training_sessions"("organizationId");

-- CreateIndex
CREATE INDEX "field_training_sessions_teamId_idx" ON "field_training_sessions"("teamId");

-- CreateIndex
CREATE INDEX "field_training_entries_athleteId_idx" ON "field_training_entries"("athleteId");

-- CreateIndex
CREATE UNIQUE INDEX "field_training_entries_fieldTrainingSessionId_athleteId_key" ON "field_training_entries"("fieldTrainingSessionId", "athleteId");

-- AddForeignKey
ALTER TABLE "field_training_sessions" ADD CONSTRAINT "field_training_sessions_calendarEventId_fkey" FOREIGN KEY ("calendarEventId") REFERENCES "calendar_events"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "field_training_sessions" ADD CONSTRAINT "field_training_sessions_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "field_training_sessions" ADD CONSTRAINT "field_training_sessions_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "field_training_entries" ADD CONSTRAINT "field_training_entries_fieldTrainingSessionId_fkey" FOREIGN KEY ("fieldTrainingSessionId") REFERENCES "field_training_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "field_training_entries" ADD CONSTRAINT "field_training_entries_athleteId_fkey" FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
