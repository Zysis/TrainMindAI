-- Foglio presenze per tutti i tipi di allenamento: RPE per atleta e carico.
--
-- 1. Il foglio può appartenere a un evento di calendario OPPURE a una sessione
--    della programmazione (prima solo la prima cosa, e obbligatoria).
-- 2. Durata effettiva e RPE di sessione: servono a calcolare il carico
--    (carico = RPE × durata) anche per gli atleti senza un RPE proprio.
-- 3. RPE del singolo atleta sulla riga di presenza.
-- 4. `detailedByAttendance` sulle sessioni: quando il foglio presenze ha
--    generato le righe per singolo atleta, la riga di squadra non va più
--    attribuita a tutta la rosa, altrimenti il carico si conta due volte.
--
-- Tutte le colonne nascono vuote o con un valore predefinito: nessun dato
-- esistente cambia significato.

ALTER TABLE "field_training_sessions" ALTER COLUMN "calendarEventId" DROP NOT NULL;
ALTER TABLE "field_training_sessions" ADD COLUMN IF NOT EXISTS "trainingSessionId" TEXT;
ALTER TABLE "field_training_sessions" ADD COLUMN IF NOT EXISTS "durationMinutes" INTEGER;
ALTER TABLE "field_training_sessions" ADD COLUMN IF NOT EXISTS "sessionRpe" INTEGER;

CREATE UNIQUE INDEX IF NOT EXISTS "field_training_sessions_trainingSessionId_key"
  ON "field_training_sessions"("trainingSessionId");

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'field_training_sessions_trainingSessionId_fkey'
  ) THEN
    ALTER TABLE "field_training_sessions"
      ADD CONSTRAINT "field_training_sessions_trainingSessionId_fkey"
      FOREIGN KEY ("trainingSessionId") REFERENCES "training_sessions"("id")
      ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

ALTER TABLE "field_training_entries" ADD COLUMN IF NOT EXISTS "rpe" INTEGER;

ALTER TABLE "training_sessions"
  ADD COLUMN IF NOT EXISTS "detailedByAttendance" BOOLEAN NOT NULL DEFAULT false;
