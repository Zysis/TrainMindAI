-- Infortuni: nuovo campo "insorgenza" e riclassifica sui cinque tipi rimasti.
--
-- I tipi selezionabili diventano: muscular, tendon, ligament, bone, joint.
-- Contusione e sovraccarico non sono più un "tipo" ma un'insorgenza, quindi:
--   contusion -> type muscular + onset contusive
--   overuse   -> type muscular + onset overuse
--   other     -> type muscular, insorgenza non specificata
--
-- La colonna si aggiunge vuota: gli infortuni esistenti non perdono nulla,
-- e la riclassifica tocca solo le righe con i tre tipi rimossi.

ALTER TABLE "injuries" ADD COLUMN IF NOT EXISTS "onset" TEXT;

UPDATE "injuries" SET "type" = 'muscular', "onset" = 'contusive' WHERE "type" = 'contusion';
UPDATE "injuries" SET "type" = 'muscular', "onset" = 'overuse'   WHERE "type" = 'overuse';
UPDATE "injuries" SET "type" = 'muscular'                        WHERE "type" = 'other';
