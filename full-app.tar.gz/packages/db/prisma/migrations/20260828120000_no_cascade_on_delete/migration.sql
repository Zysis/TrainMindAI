-- Rete di sicurezza sul vincolo `training_plans.periodizationPlanId`.
--
-- Nello schema Prisma la relazione e' opzionale, quindi il default e' gia'
-- ON DELETE SET NULL: cancellare una periodizzazione lascia in piedi i
-- mesocicli collegati. Ma questo database e' stato costruito con `db push`
-- ripetuti e in passato si e' gia' trovato disallineato rispetto allo schema:
-- se in produzione il vincolo fosse CASCADE, eliminare una periodizzazione
-- distruggerebbe in silenzio mesocicli, settimane, sessioni e i loro esercizi.
--
-- Questa migration guarda com'e' fatto il vincolo davvero e lo corregge solo
-- se serve. Se e' gia' a posto non fa nulla, e si puo' rilanciare.

DO $mig$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_constraint c
    JOIN pg_class t ON t.oid = c.conrelid
    WHERE t.relname = 'training_plans'
      AND c.conname = 'training_plans_periodizationPlanId_fkey'
      AND c.confdeltype = 'c'          -- 'c' = CASCADE, 'n' = SET NULL
  ) THEN
    ALTER TABLE "training_plans"
      DROP CONSTRAINT "training_plans_periodizationPlanId_fkey";

    ALTER TABLE "training_plans"
      ADD CONSTRAINT "training_plans_periodizationPlanId_fkey"
      FOREIGN KEY ("periodizationPlanId") REFERENCES "periodization_plans"("id")
      ON DELETE SET NULL ON UPDATE CASCADE;

    RAISE NOTICE 'no_cascade_on_delete: era CASCADE, convertito in SET NULL.';
  ELSE
    RAISE NOTICE 'no_cascade_on_delete: vincolo gia corretto, non faccio nulla.';
  END IF;
END
$mig$;
