-- La sede dell'infortunio diventa un vocabolario chiuso.
--
-- Fino al 2/9/2026 `POST /athletes/:id/injuries` non aveva nessuno schema di
-- validazione: faceva `request.body as {...}` e scriveva. In `location` e'
-- quindi finito anche testo libero in italiano ("Avambraccio"), che la scheda
-- medica del report giornaliero non sa mappare su nessuna parte anatomica —
-- il preparatore si ritrovava i campi vuoti e doveva riscrivere a mano una
-- cosa che il sistema aveva gia'.
--
-- Da qui in avanti l'API accetta solo i codici di INJURY_LOCATION_CODES.
-- Questa migration mette in riga quello che c'e' gia'.

-- PRIMA le traduzioni certe. Queste tre stringhe sono quelle che i seed
-- scrivevano fino al 3/9/2026, e in produzione sono le uniche non conformi:
-- sono traducibili senza margine di dubbio, e buttarle in 'other' sarebbe
-- stato distruggere un dato che sappiamo leggere. Il tendine rotuleo non ha
-- un codice proprio fra le sedi: la sede piu' vicina e' il ginocchio, e il
-- dettaglio resta comunque nel campo `type` dell'infortunio.
UPDATE "injuries" SET "location" = 'ankle_r'     WHERE "location" = 'Caviglia destra';
UPDATE "injuries" SET "location" = 'hamstring_l' WHERE "location" = 'Ischiocrurali sinistri';
UPDATE "injuries" SET "location" = 'knee_r'      WHERE "location" = 'Tendine rotuleo destro';

-- POI il resto. Il valore originale NON si butta: finisce nelle note, cosi'
-- l'informazione clinica resta leggibile anche dove il codice diventa 'other'.
UPDATE "injuries"
SET
  "notes" = CASE
    WHEN "notes" IS NULL OR btrim("notes") = ''
      THEN 'Sede indicata prima della normalizzazione: ' || "location"
    ELSE "notes" || E'\n' || 'Sede indicata prima della normalizzazione: ' || "location"
  END,
  "location" = 'other'
WHERE "location" NOT IN (
  'ankle_l', 'ankle_r',
  'knee_l', 'knee_r',
  'hamstring_l', 'hamstring_r',
  'quadriceps_l', 'quadriceps_r',
  'calf_l', 'calf_r',
  'groin',
  'hip_l', 'hip_r',
  'back_lower', 'back_upper',
  'shoulder_l', 'shoulder_r',
  'arm_l', 'arm_r',
  'wrist_l', 'wrist_r',
  'finger',
  'foot_l', 'foot_r',
  'other'
);
