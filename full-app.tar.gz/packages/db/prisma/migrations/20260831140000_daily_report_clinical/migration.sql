-- Colonne cliniche sulla riga giocatore del report giornaliero: le voci del
-- foglio di fine giornata cartaceo (prossimo allenamento, infortunio, parte
-- anatomica, lato, stato, taping, trattamento, tipo allenamento, previsione).
--
-- Tutte TEXT nullable e senza default: il foglio si compila per eccezione e la
-- riga di un giocatore sano resta vuota. Nessun backfill: i report gia'
-- salvati non hanno questi dati e inventarli sarebbe peggio che lasciarli
-- vuoti.
--
-- TEXT e non ENUM Postgres di proposito: sono liste di lavoro del fisio, che
-- cambieranno; con un enum ogni voce aggiunta sarebbe una migrazione, e una
-- voce rimossa romperebbe le righe storiche. La validazione dei codici sta
-- nello schema zod dell'API, dove si aggiorna senza toccare il database.

ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "nextTraining"   TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "injuryType"     TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "bodyPart"       TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "side"           TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "clinicalStatus" TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "taping"         TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "treatment"      TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "trainingType"   TEXT;
ALTER TABLE "daily_report_entries" ADD COLUMN IF NOT EXISTS "forecast"       TEXT;
