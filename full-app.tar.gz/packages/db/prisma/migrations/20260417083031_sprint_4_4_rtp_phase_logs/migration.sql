-- CreateTable
CREATE TABLE "rtp_phase_logs" (
    "id" TEXT NOT NULL,
    "rtpProtocolId" TEXT NOT NULL,
    "fromPhase" "RTPPhase" NOT NULL,
    "toPhase" "RTPPhase" NOT NULL,
    "changedById" TEXT NOT NULL,
    "reason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "rtp_phase_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "clearance_criteria" (
    "id" TEXT NOT NULL,
    "rtpProtocolId" TEXT NOT NULL,
    "phase" "RTPPhase" NOT NULL,
    "description" TEXT NOT NULL,
    "isMet" BOOLEAN NOT NULL DEFAULT false,
    "metAt" TIMESTAMP(3),
    "metById" TEXT,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "clearance_criteria_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "rtp_phase_logs_rtpProtocolId_idx" ON "rtp_phase_logs"("rtpProtocolId");

-- CreateIndex
CREATE INDEX "clearance_criteria_rtpProtocolId_phase_idx" ON "clearance_criteria"("rtpProtocolId", "phase");

-- AddForeignKey
ALTER TABLE "rtp_phase_logs" ADD CONSTRAINT "rtp_phase_logs_rtpProtocolId_fkey" FOREIGN KEY ("rtpProtocolId") REFERENCES "rtp_protocols"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "rtp_phase_logs" ADD CONSTRAINT "rtp_phase_logs_changedById_fkey" FOREIGN KEY ("changedById") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clearance_criteria" ADD CONSTRAINT "clearance_criteria_rtpProtocolId_fkey" FOREIGN KEY ("rtpProtocolId") REFERENCES "rtp_protocols"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "clearance_criteria" ADD CONSTRAINT "clearance_criteria_metById_fkey" FOREIGN KEY ("metById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
