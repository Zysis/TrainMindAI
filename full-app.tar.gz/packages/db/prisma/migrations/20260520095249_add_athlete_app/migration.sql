/*
  Warnings:

  - A unique constraint covering the columns `[athleteId]` on the table `users` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "InviteStatus" AS ENUM ('PENDING', 'ACCEPTED', 'EXPIRED', 'REVOKED');

-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'ATHLETE';

-- AlterTable
ALTER TABLE "session_logs" ADD COLUMN     "exerciseChecks" JSONB,
ADD COLUMN     "viewedAt" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "athleteId" TEXT,
ADD COLUMN     "pushSubscription" JSONB;

-- AlterTable
ALTER TABLE "wellness_logs" ADD COLUMN     "mediaUrls" TEXT[],
ADD COLUMN     "submittedBy" TEXT;

-- CreateTable
CREATE TABLE "athlete_invites" (
    "id" TEXT NOT NULL,
    "athleteId" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "status" "InviteStatus" NOT NULL DEFAULT 'PENDING',
    "invitedById" TEXT NOT NULL,
    "organizationId" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "acceptedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "athlete_invites_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "athlete_invites_token_key" ON "athlete_invites"("token");

-- CreateIndex
CREATE INDEX "athlete_invites_token_idx" ON "athlete_invites"("token");

-- CreateIndex
CREATE INDEX "athlete_invites_email_idx" ON "athlete_invites"("email");

-- CreateIndex
CREATE INDEX "athlete_invites_organizationId_status_idx" ON "athlete_invites"("organizationId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "users_athleteId_key" ON "users"("athleteId");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_athleteId_fkey" FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "athlete_invites" ADD CONSTRAINT "athlete_invites_athleteId_fkey" FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "athlete_invites" ADD CONSTRAINT "athlete_invites_invitedById_fkey" FOREIGN KEY ("invitedById") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "athlete_invites" ADD CONSTRAINT "athlete_invites_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
