-- Calendario: rinomina dei tipi evento.
--   training       -> gym      (Allenamento in sala pesi)
--   field_training -> basket   (Allenamenti Basket)
-- match, medical, meeting e other restano invariati.
-- Le sessioni dei piani di allenamento NON sono righe di questa tabella:
-- l'API le costruisce al volo col tipo 'session'.
--
-- Cambia solo la colonna `type`: nessuna riga viene creata o eliminata.
-- Per tornare indietro basta invertire i due UPDATE.

UPDATE "calendar_events" SET "type" = 'basket' WHERE "type" = 'field_training';
UPDATE "calendar_events" SET "type" = 'gym'    WHERE "type" = 'training';
