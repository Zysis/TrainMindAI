-- Report post-partita: risultato sulla sessione, aspettative di allenamento
-- sulla riga giocatore.
--
-- `homeScore`/`awayScore` e non "nostro/loro": il tabellone si legge come e'
-- scritto, e chi delle due squadre siamo lo dice gia' `isHome` sull'evento di
-- calendario. Salvando "nostro/loro" il punteggio non sarebbe leggibile senza
-- andare a prendere un altro campo su un'altra tabella.
--
-- `competition` e' testo libero: le competizioni cambiano ogni stagione e
-- un'anagrafica costringerebbe a censire un campionato prima di poter
-- registrare un'amichevole.
--
-- `readiness` sta sulla riga giocatore della PARTITA e non sul report
-- giornaliero del giorno dopo: il foglio post-partita deve restare
-- autosufficiente. Nullable: una partita gia' archiviata non ha aspettative
-- e inventarle sarebbe peggio che lasciarle vuote.

ALTER TABLE "game_sessions" ADD COLUMN IF NOT EXISTS "homeScore"   INTEGER;
ALTER TABLE "game_sessions" ADD COLUMN IF NOT EXISTS "awayScore"   INTEGER;
ALTER TABLE "game_sessions" ADD COLUMN IF NOT EXISTS "competition" TEXT;

ALTER TABLE "game_player_entries" ADD COLUMN IF NOT EXISTS "readiness"     INTEGER;
ALTER TABLE "game_player_entries" ADD COLUMN IF NOT EXISTS "readinessNote" TEXT;
