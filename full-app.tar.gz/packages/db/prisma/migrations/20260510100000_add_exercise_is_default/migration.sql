-- AlterTable: add isDefault column (defaults false for new exercises)
ALTER TABLE "exercises" ADD COLUMN "isDefault" BOOLEAN NOT NULL DEFAULT false;

-- Mark ALL existing exercises as defaults (they were imported via seed)
UPDATE "exercises" SET "isDefault" = true;
