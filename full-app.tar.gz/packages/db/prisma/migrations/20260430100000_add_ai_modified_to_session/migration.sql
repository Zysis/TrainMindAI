-- AlterTable
ALTER TABLE "training_sessions" ADD COLUMN "aiModified" BOOLEAN NOT NULL DEFAULT false;
