-- AlterTable
ALTER TABLE "athletes" ADD COLUMN     "email" TEXT;
