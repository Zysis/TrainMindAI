-- Report di fine giornata: una testata per squadra/giorno e una riga per
-- giocatore con lo stato di disponibilita' 0-5.
--
-- La riga porta anche `date`, copiata dalla testata. E' una denormalizzazione
-- voluta: lo storico di disponibilita' di un atleta ("quanti giorni e' stato a
-- 5 dopo l'infortunio?") diventa una query su una tabella sola, senza join,
-- ed e' esattamente la lettura che serve alla scheda atleta. La coerenza fra
-- le due date e' garantita dall'API, che le scrive nella stessa transazione.
--
-- `date` e' DATE e non TIMESTAMP: il report e' della giornata, non di un
-- istante, e con TIMESTAMP il vincolo di unicita' per giorno non terrebbe
-- (due salvataggi alle 19:00 e alle 21:00 sarebbero due report distinti).
--
-- ON DELETE: cancellare una squadra porta via i suoi report (senza squadra non
-- vogliono dire niente); cancellare la testata porta via le righe. L'atleta
-- invece NON cancella: una riga di storico senza atleta e' un dato rotto, e
-- l'app non cancella gli atleti, li archivia.

CREATE TABLE IF NOT EXISTS "daily_reports" (
  "id"             TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "teamId"         TEXT NOT NULL,
  "date"           DATE NOT NULL,
  "activities"     JSONB NOT NULL DEFAULT '[]',
  "teamLines"      TEXT,
  "createdById"    TEXT,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL,
  CONSTRAINT "daily_reports_pkey" PRIMARY KEY ("id")
);

CREATE TABLE IF NOT EXISTS "daily_report_entries" (
  "id"            TEXT NOT NULL,
  "dailyReportId" TEXT NOT NULL,
  "athleteId"     TEXT NOT NULL,
  "date"          DATE NOT NULL,
  "status"        INTEGER NOT NULL,
  "note"          TEXT,
  "orderIndex"    INTEGER NOT NULL DEFAULT 0,
  "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"     TIMESTAMP(3) NOT NULL,
  CONSTRAINT "daily_report_entries_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "daily_reports_teamId_date_key"
  ON "daily_reports" ("teamId", "date");
CREATE INDEX IF NOT EXISTS "daily_reports_organizationId_date_idx"
  ON "daily_reports" ("organizationId", "date");

CREATE UNIQUE INDEX IF NOT EXISTS "daily_report_entries_dailyReportId_athleteId_key"
  ON "daily_report_entries" ("dailyReportId", "athleteId");
CREATE INDEX IF NOT EXISTS "daily_report_entries_athleteId_date_idx"
  ON "daily_report_entries" ("athleteId", "date");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'daily_reports_organizationId_fkey') THEN
    ALTER TABLE "daily_reports" ADD CONSTRAINT "daily_reports_organizationId_fkey"
      FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'daily_reports_teamId_fkey') THEN
    ALTER TABLE "daily_reports" ADD CONSTRAINT "daily_reports_teamId_fkey"
      FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'daily_reports_createdById_fkey') THEN
    ALTER TABLE "daily_reports" ADD CONSTRAINT "daily_reports_createdById_fkey"
      FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'daily_report_entries_dailyReportId_fkey') THEN
    ALTER TABLE "daily_report_entries" ADD CONSTRAINT "daily_report_entries_dailyReportId_fkey"
      FOREIGN KEY ("dailyReportId") REFERENCES "daily_reports"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'daily_report_entries_athleteId_fkey') THEN
    ALTER TABLE "daily_report_entries" ADD CONSTRAINT "daily_report_entries_athleteId_fkey"
      FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
  END IF;
END $$;
