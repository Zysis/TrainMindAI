-- AlterTable: make date and weekId nullable, add isTemplate and organizationId
ALTER TABLE "training_sessions" ALTER COLUMN "date" DROP NOT NULL;
ALTER TABLE "training_sessions" ALTER COLUMN "weekId" DROP NOT NULL;
ALTER TABLE "training_sessions" ADD COLUMN "isTemplate" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "training_sessions" ADD COLUMN "organizationId" TEXT;

-- Backfill organizationId from the related week → trainingPlan
UPDATE "training_sessions" ts
SET "organizationId" = tp."organizationId"
FROM "weeks" w
JOIN "training_plans" tp ON tp."id" = w."trainingPlanId"
WHERE ts."weekId" = w."id"
AND ts."organizationId" IS NULL;

-- Now make organizationId required
ALTER TABLE "training_sessions" ALTER COLUMN "organizationId" SET NOT NULL;

-- Add foreign key
ALTER TABLE "training_sessions" ADD CONSTRAINT "training_sessions_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Add index
CREATE INDEX "training_sessions_organizationId_isTemplate_idx" ON "training_sessions"("organizationId", "isTemplate");
