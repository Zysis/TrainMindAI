-- Logo (o foto) della squadra, tenuto come data URL nella colonna, come gia'
-- si fa per `athletes.photoUrl`: nessun file da servire, nessuno storage da
-- configurare, e il logo segue il backup del database.

ALTER TABLE "teams" ADD COLUMN IF NOT EXISTS "logoUrl" TEXT;
