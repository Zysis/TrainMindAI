-- AlterTable
ALTER TABLE "athletes" ADD COLUMN "team" TEXT;
