-- Field training: esercizi con cronometro + numero atleti disponibili
ALTER TABLE "field_training_sessions" ADD COLUMN IF NOT EXISTS "availableAthletes" INTEGER;
ALTER TABLE "field_training_sessions" ADD COLUMN IF NOT EXISTS "exercises" JSONB NOT NULL DEFAULT '[]';
