-- Wellness: su tutte e cinque le voci 5 diventa il valore migliore.
--
-- Prima Fatica, Dolore e Stress andavano da 1 (nessuno) a 5 (estremo): il
-- significato era opposto a quello di Sonno e Umore, e il punteggio composito
-- li ribaltava con (6 - x). Ora la scala e' unica, quindi i dati gia' raccolti
-- su quelle tre voci vanno riflessi.
--
-- ATTENZIONE: la conversione e' simmetrica, rilanciarla torna indietro.
-- Per questo la migrazione si segna in `_trainmind_data_migrations`: se la
-- lanci due volte, la seconda non fa nulla e te lo dice. Serve perche' in
-- produzione il gesto istintivo, dopo un errore a meta' deploy, e' rilanciare.

CREATE TABLE IF NOT EXISTS "_trainmind_data_migrations" (
  "name"       TEXT PRIMARY KEY,
  "applied_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);

DO $mig$
BEGIN
  IF EXISTS (
    SELECT 1 FROM "_trainmind_data_migrations"
    WHERE "name" = '20260824120000_wellness_scale_flip'
  ) THEN
    RAISE NOTICE 'wellness_scale_flip: gia applicata, non faccio nulla.';
    RETURN;
  END IF;

  UPDATE "wellness_logs"
  SET "fatigue"  = 6 - "fatigue",
      "soreness" = 6 - "soreness",
      "stress"   = 6 - "stress";

  -- Le regole di alert su fatica e dolore avevano soglie scritte nella vecchia
  -- logica (es. "fatica >= 4" = molto affaticato). Vanno riflesse anche loro,
  -- soglia e verso del confronto, altrimenti scatterebbero sugli atleti freschi.
  -- Le regole su wellness_score non si toccano: il punteggio resta 0-100 con
  -- alto = buono.

  UPDATE "alert_rules"
  SET "condition" = jsonb_set(
        jsonb_set(
          "condition"::jsonb,
          '{threshold}',
          to_jsonb(6 - ("condition"->>'threshold')::numeric)
        ),
        '{operator}',
        to_jsonb(
          CASE "condition"->>'operator'
            WHEN '>'  THEN '<'
            WHEN '>=' THEN '<='
            WHEN '<'  THEN '>'
            WHEN '<=' THEN '>='
            ELSE "condition"->>'operator'
          END
        )
      )
  WHERE "condition"->>'metric' IN ('fatigue', 'soreness')
    AND "condition" ? 'threshold'
    AND "condition" ? 'operator';

  INSERT INTO "_trainmind_data_migrations" ("name")
  VALUES ('20260824120000_wellness_scale_flip');

  RAISE NOTICE 'wellness_scale_flip: applicata.';
END $mig$;
