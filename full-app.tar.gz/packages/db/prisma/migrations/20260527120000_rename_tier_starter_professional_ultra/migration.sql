-- ============================================================
-- Rinomina i valori dell'enum OrganizationTier e allinea la
-- colonna Stripe `subscriptionTier` al naming pubblico nuovo:
--
--   FREE       → STARTER       (e "free"  → "starter")
--   PRO        → PROFESSIONAL  (e "pro"   → "professional")
--   ENTERPRISE → ULTRA         (e "team"/"enterprise" → "ultra")
--
-- Compatibile con PostgreSQL 12+ (ALTER TYPE ... RENAME VALUE
-- è transazionale a partire da Postgres 12).
-- ============================================================

-- 1) Rinomina i valori dell'enum esistente (preserva i dati).
ALTER TYPE "OrganizationTier" RENAME VALUE 'FREE' TO 'STARTER';
ALTER TYPE "OrganizationTier" RENAME VALUE 'PRO' TO 'PROFESSIONAL';
ALTER TYPE "OrganizationTier" RENAME VALUE 'ENTERPRISE' TO 'ULTRA';

-- 2) Aggiorna il default della colonna `tier`.
ALTER TABLE "organizations" ALTER COLUMN "tier" SET DEFAULT 'STARTER';

-- 3) Backfill della colonna Stripe `subscriptionTier` (stringa libera).
UPDATE "organizations"
   SET "subscriptionTier" = 'starter'
 WHERE "subscriptionTier" IS NULL
    OR "subscriptionTier" = 'free';

UPDATE "organizations"
   SET "subscriptionTier" = 'professional'
 WHERE "subscriptionTier" = 'pro';

UPDATE "organizations"
   SET "subscriptionTier" = 'ultra'
 WHERE "subscriptionTier" IN ('team', 'enterprise');

-- 4) Aggiorna il default della colonna Stripe.
ALTER TABLE "organizations" ALTER COLUMN "subscriptionTier" SET DEFAULT 'starter';
