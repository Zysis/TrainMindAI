-- Due colonne su training_plans, entrambe additive e senza impatto sui dati
-- esistenti. Stanno insieme perche' nascono dalla stessa modifica al
-- generatore di mesocicli e nessuna delle due e' ancora in produzione.
--
-- 1. trainingDays: giorni di allenamento in numerazione ISO (1 = lunedi', 7 =
--    domenica). Servono a datare le sessioni sui giorni reali invece che su
--    giorni consecutivi a partire da oggi, e restano visibili sulla scheda.
--    Array vuoto come default: i mesocicli esistenti non dichiarano nessun
--    pattern e continuano a comportarsi come prima.
--
-- 2. aiGenerated: distingue i mesocicli usciti da "Genera con AI". I piani
--    gia' in archivio restano `false` — non c'e' modo di ricostruire a
--    posteriori come sono nati, e dichiararli AI sarebbe una bugia.

ALTER TABLE "training_plans"
  ADD COLUMN IF NOT EXISTS "trainingDays" INTEGER[] NOT NULL DEFAULT ARRAY[]::INTEGER[];

ALTER TABLE "training_plans"
  ADD COLUMN IF NOT EXISTS "aiGenerated" BOOLEAN NOT NULL DEFAULT false;
