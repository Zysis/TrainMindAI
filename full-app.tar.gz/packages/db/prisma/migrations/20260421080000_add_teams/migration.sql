-- CreateTable
CREATE TABLE "teams" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "color" TEXT,
    "organizationId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "teams_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "athlete_teams" (
    "id" TEXT NOT NULL,
    "athleteId" TEXT NOT NULL,
    "teamId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "athlete_teams_pkey" PRIMARY KEY ("id")
);

-- Add teamId columns
ALTER TABLE "training_plans" ADD COLUMN "teamId" TEXT;
ALTER TABLE "periodization_plans" ADD COLUMN "teamId" TEXT;
ALTER TABLE "calendar_events" ADD COLUMN "teamId" TEXT;

-- CreateIndex
CREATE INDEX "teams_organizationId_idx" ON "teams"("organizationId");
CREATE UNIQUE INDEX "teams_organizationId_name_key" ON "teams"("organizationId", "name");

CREATE INDEX "athlete_teams_teamId_idx" ON "athlete_teams"("teamId");
CREATE UNIQUE INDEX "athlete_teams_athleteId_teamId_key" ON "athlete_teams"("athleteId", "teamId");

CREATE INDEX "training_plans_teamId_idx" ON "training_plans"("teamId");
CREATE INDEX "periodization_plans_teamId_idx" ON "periodization_plans"("teamId");
CREATE INDEX "calendar_events_teamId_idx" ON "calendar_events"("teamId");

-- AddForeignKey
ALTER TABLE "teams" ADD CONSTRAINT "teams_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "athlete_teams" ADD CONSTRAINT "athlete_teams_athleteId_fkey" FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "athlete_teams" ADD CONSTRAINT "athlete_teams_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "training_plans" ADD CONSTRAINT "training_plans_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "periodization_plans" ADD CONSTRAINT "periodization_plans_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "calendar_events" ADD CONSTRAINT "calendar_events_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE SET NULL ON UPDATE CASCADE;
