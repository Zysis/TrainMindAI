-- CreateEnum
CREATE TYPE "PeriodizationType" AS ENUM ('LINEAR', 'UNDULATING', 'BLOCK', 'REVERSE_LINEAR', 'CONJUGATE');

-- CreateEnum
CREATE TYPE "MesocyclePhase" AS ENUM ('PREPARATION', 'SPECIFIC', 'COMPETITION', 'TRANSITION', 'TAPER', 'RECOVERY');

-- CreateEnum
CREATE TYPE "IntensityLevel" AS ENUM ('VERY_LOW', 'LOW', 'MODERATE', 'HIGH', 'VERY_HIGH');

-- CreateTable
CREATE TABLE "periodization_plans" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "type" "PeriodizationType" NOT NULL DEFAULT 'BLOCK',
    "startDate" TIMESTAMP(3) NOT NULL,
    "endDate" TIMESTAMP(3) NOT NULL,
    "totalWeeks" INTEGER NOT NULL,
    "organizationId" TEXT NOT NULL,
    "createdById" TEXT NOT NULL,
    "isTemplate" BOOLEAN NOT NULL DEFAULT false,
    "templateCategory" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "periodization_plans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "mesocycles" (
    "id" TEXT NOT NULL,
    "periodizationPlanId" TEXT NOT NULL,
    "orderIndex" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "phase" "MesocyclePhase" NOT NULL,
    "durationWeeks" INTEGER NOT NULL,
    "targetLoadPercent" DOUBLE PRECISION NOT NULL,
    "intensityDistribution" JSONB,
    "notes" TEXT,
    "color" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "mesocycles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "microcycles" (
    "id" TEXT NOT NULL,
    "mesocycleId" TEXT NOT NULL,
    "weekNumber" INTEGER NOT NULL,
    "loadPercent" DOUBLE PRECISION NOT NULL,
    "intensity" "IntensityLevel" NOT NULL DEFAULT 'MODERATE',
    "volume" DOUBLE PRECISION,
    "sessionsCount" INTEGER NOT NULL DEFAULT 5,
    "focusAreas" TEXT[],
    "isDeload" BOOLEAN NOT NULL DEFAULT false,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "microcycles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "simulations" (
    "id" TEXT NOT NULL,
    "periodizationPlanId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "parameters" JSONB NOT NULL,
    "results" JSONB,
    "aiInsights" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "simulations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "periodization_plans_organizationId_idx" ON "periodization_plans"("organizationId");

-- CreateIndex
CREATE INDEX "periodization_plans_isTemplate_idx" ON "periodization_plans"("isTemplate");

-- CreateIndex
CREATE UNIQUE INDEX "mesocycles_periodizationPlanId_orderIndex_key" ON "mesocycles"("periodizationPlanId", "orderIndex");

-- CreateIndex
CREATE UNIQUE INDEX "microcycles_mesocycleId_weekNumber_key" ON "microcycles"("mesocycleId", "weekNumber");

-- CreateIndex
CREATE INDEX "simulations_periodizationPlanId_idx" ON "simulations"("periodizationPlanId");

-- AddForeignKey
ALTER TABLE "periodization_plans" ADD CONSTRAINT "periodization_plans_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "periodization_plans" ADD CONSTRAINT "periodization_plans_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "mesocycles" ADD CONSTRAINT "mesocycles_periodizationPlanId_fkey" FOREIGN KEY ("periodizationPlanId") REFERENCES "periodization_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "microcycles" ADD CONSTRAINT "microcycles_mesocycleId_fkey" FOREIGN KEY ("mesocycleId") REFERENCES "mesocycles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "simulations" ADD CONSTRAINT "simulations_periodizationPlanId_fkey" FOREIGN KEY ("periodizationPlanId") REFERENCES "periodization_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;
