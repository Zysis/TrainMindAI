-- AlterTable: Add periodizationPlanId to training_plans
ALTER TABLE "training_plans" ADD COLUMN "periodizationPlanId" TEXT;

-- AlterTable: Add microcycleId to weeks
ALTER TABLE "weeks" ADD COLUMN "microcycleId" TEXT;

-- CreateIndex
CREATE INDEX "training_plans_periodizationPlanId_idx" ON "training_plans"("periodizationPlanId");
CREATE INDEX "weeks_microcycleId_idx" ON "weeks"("microcycleId");

-- AddForeignKey
ALTER TABLE "training_plans" ADD CONSTRAINT "training_plans_periodizationPlanId_fkey" FOREIGN KEY ("periodizationPlanId") REFERENCES "periodization_plans"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weeks" ADD CONSTRAINT "weeks_microcycleId_fkey" FOREIGN KEY ("microcycleId") REFERENCES "microcycles"("id") ON DELETE SET NULL ON UPDATE CASCADE;
