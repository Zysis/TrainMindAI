-- CreateTable
CREATE TABLE "game_sessions" (
    "id" TEXT NOT NULL,
    "calendarEventId" TEXT NOT NULL,
    "teamId" TEXT,
    "organizationId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'IN_PROGRESS',
    "quarters" INTEGER NOT NULL DEFAULT 4,
    "quarterDurationMs" INTEGER NOT NULL DEFAULT 600000,
    "overtimes" INTEGER NOT NULL DEFAULT 0,
    "currentQuarter" INTEGER NOT NULL DEFAULT 1,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "game_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "game_player_entries" (
    "id" TEXT NOT NULL,
    "gameSessionId" TEXT NOT NULL,
    "athleteId" TEXT NOT NULL,
    "totalPlayingMs" INTEGER NOT NULL DEFAULT 0,
    "stints" JSONB NOT NULL DEFAULT '[]',
    "onCourt" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "game_player_entries_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "game_sessions_calendarEventId_key" ON "game_sessions"("calendarEventId");

-- CreateIndex
CREATE INDEX "game_sessions_organizationId_idx" ON "game_sessions"("organizationId");

-- CreateIndex
CREATE INDEX "game_sessions_teamId_idx" ON "game_sessions"("teamId");

-- CreateIndex
CREATE INDEX "game_player_entries_athleteId_idx" ON "game_player_entries"("athleteId");

-- CreateIndex
CREATE UNIQUE INDEX "game_player_entries_gameSessionId_athleteId_key" ON "game_player_entries"("gameSessionId", "athleteId");

-- AddForeignKey
ALTER TABLE "game_sessions" ADD CONSTRAINT "game_sessions_calendarEventId_fkey" FOREIGN KEY ("calendarEventId") REFERENCES "calendar_events"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "game_sessions" ADD CONSTRAINT "game_sessions_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "game_sessions" ADD CONSTRAINT "game_sessions_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "game_player_entries" ADD CONSTRAINT "game_player_entries_gameSessionId_fkey" FOREIGN KEY ("gameSessionId") REFERENCES "game_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "game_player_entries" ADD CONSTRAINT "game_player_entries_athleteId_fkey" FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
