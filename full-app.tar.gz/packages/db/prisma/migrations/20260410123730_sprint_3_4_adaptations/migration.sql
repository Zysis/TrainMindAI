-- CreateTable
CREATE TABLE "plan_adaptations" (
    "id" TEXT NOT NULL,
    "trainingSessionId" TEXT,
    "athleteId" TEXT NOT NULL,
    "organizationId" TEXT NOT NULL,
    "proposedById" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "reason" TEXT NOT NULL,
    "aiReasoning" TEXT,
    "metrics" JSONB NOT NULL,
    "originalPlan" JSONB NOT NULL,
    "proposedPlan" JSONB NOT NULL,
    "changes" JSONB NOT NULL,
    "volumeDelta" DOUBLE PRECISION,
    "intensityDelta" DOUBLE PRECISION,
    "appliedAt" TIMESTAMP(3),
    "reviewedAt" TIMESTAMP(3),
    "reviewedById" TEXT,
    "reviewNotes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "plan_adaptations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "plan_adaptations_athleteId_status_idx" ON "plan_adaptations"("athleteId", "status");

-- CreateIndex
CREATE INDEX "plan_adaptations_organizationId_status_idx" ON "plan_adaptations"("organizationId", "status");

-- CreateIndex
CREATE INDEX "plan_adaptations_createdAt_idx" ON "plan_adaptations"("createdAt");

-- AddForeignKey
ALTER TABLE "plan_adaptations" ADD CONSTRAINT "plan_adaptations_athleteId_fkey" FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "plan_adaptations" ADD CONSTRAINT "plan_adaptations_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "plan_adaptations" ADD CONSTRAINT "plan_adaptations_proposedById_fkey" FOREIGN KEY ("proposedById") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "plan_adaptations" ADD CONSTRAINT "plan_adaptations_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
