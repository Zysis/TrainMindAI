-- Ruoli degli atleti: una forma sola, la sigla.
--
-- `seed.ts` scriveva i nomi per esteso, `seed-demo.ts` e `seed-team14.ts` le
-- sigle, e il form di creazione mandava i nomi per esteso. Nella stessa colonna
-- convivevano quindi 'Point Guard' e 'PG', e il filtro per ruolo (confronto
-- esatto) non trovava mai gli atleti salvati nell'altra forma.
--
-- Idempotente: dopo il primo giro nessuna riga combacia piu' con le WHERE.

UPDATE "athletes" SET "position" = 'PG' WHERE "position" = 'Point Guard';
UPDATE "athletes" SET "position" = 'SG' WHERE "position" = 'Shooting Guard';
UPDATE "athletes" SET "position" = 'SF' WHERE "position" = 'Small Forward';
UPDATE "athletes" SET "position" = 'PF' WHERE "position" = 'Power Forward';
UPDATE "athletes" SET "position" = 'C'  WHERE "position" = 'Center';
