-- Dettagli della partita sull'evento di calendario: avversario, casa o
-- trasferta, campo di gioco.
--
-- Stanno su calendar_events e non su game_sessions perche' esistono prima che
-- qualcuno apra il foglio dei minuti: la partita si segna a calendario giorni
-- prima, e il campo serve gia' li'. La sessione di gioco li legge.
--
-- `opponent` e' testo libero e non una relazione a teams: `teams` sono le
-- squadre DELL'organizzazione, gli avversari no. Costringere a censire ogni
-- avversario prima di poter segnare una partita sarebbe un attrito che
-- nessuno accetterebbe, e riempirebbe l'anagrafica di squadre fantasma che
-- poi comparirebbero nei menu di tutta l'app.
--
-- `isHome` e' nullable a tre stati: true casa, false trasferta, NULL non
-- specificato. Con un default false le partite gia' a calendario
-- diventerebbero tutte "in trasferta", che e' un'informazione inventata.

ALTER TABLE "calendar_events" ADD COLUMN IF NOT EXISTS "opponent" TEXT;
ALTER TABLE "calendar_events" ADD COLUMN IF NOT EXISTS "isHome"   BOOLEAN;
ALTER TABLE "calendar_events" ADD COLUMN IF NOT EXISTS "venue"    TEXT;
