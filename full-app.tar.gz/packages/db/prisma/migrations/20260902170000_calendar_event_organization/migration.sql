-- Il calendario diventa della societa', non della persona.
--
-- Prima `calendar_events` era filtrato per `userId`: due preparatori della
-- stessa societa' non vedevano gli eventi l'uno dell'altro, e aprire il foglio
-- di campo o i minuti partita su un evento creato da un collega rispondeva
-- "evento non trovato". `userId` resta, ma come "chi l'ha creato".
--
-- ORDINE NEL DEPLOY: questa migration va lanciata PRIMA di `prisma db push`.
-- Lo schema dichiara `organizationId` obbligatoria: se `db push` arrivasse per
-- primo su una tabella con righe dentro, dovrebbe aggiungere una colonna NOT
-- NULL senza default e non potrebbe farlo se non svuotando la tabella.
-- Qui la colonna nasce annullabile, si popola, e solo dopo diventa
-- obbligatoria: quando poi `db push` guarda, trova gia' tutto a posto.
--
-- Idempotente: ogni passo e' guardato, rilanciarla non fa nulla.

-- 1. La colonna nasce annullabile, altrimenti non si puo' popolare.
ALTER TABLE "calendar_events" ADD COLUMN IF NOT EXISTS "organizationId" TEXT;

-- 2. Ogni evento eredita l'organizzazione di chi l'ha creato.
UPDATE "calendar_events" ce
SET "organizationId" = u."organizationId"
FROM "users" u
WHERE ce."userId" = u.id
  AND ce."organizationId" IS NULL;

-- 3. Gli eventi senza squadra vanno all'Under 14 della LORO organizzazione
--    (decisione dell'utente, 2/9/2026). Dove quella squadra non esiste
--    l'evento resta senza: il vincolo di squadra obbligatoria vale solo sui
--    tipi collettivi e solo da qui in avanti, quindi lo storico non si rompe.
UPDATE "calendar_events" ce
SET "teamId" = t.id
FROM "teams" t
WHERE ce."teamId" IS NULL
  AND ce."organizationId" IS NOT NULL
  AND t."organizationId" = ce."organizationId"
  AND lower(t.name) = 'under 14';

-- 4. Adesso la colonna puo' diventare obbligatoria.
--    Se restasse anche un solo evento senza organizzazione (un utente
--    cancellato, per dire) il vincolo non passerebbe: meglio fermarsi qui con
--    un messaggio leggibile che con un errore di Postgres a meta' deploy.
DO $cal$
DECLARE orfani integer;
BEGIN
  SELECT count(*) INTO orfani
  FROM "calendar_events" WHERE "organizationId" IS NULL;

  IF orfani > 0 THEN
    RAISE EXCEPTION
      'calendar_event_organization: % eventi senza organizzazione. Guarda chi li ha creati con: SELECT id, title, "userId" FROM calendar_events WHERE "organizationId" IS NULL;',
      orfani;
  END IF;
END $cal$;

ALTER TABLE "calendar_events" ALTER COLUMN "organizationId" SET NOT NULL;

CREATE INDEX IF NOT EXISTS "calendar_events_organizationId_idx"
  ON "calendar_events"("organizationId");

DO $fk$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'calendar_events_organizationId_fkey'
  ) THEN
    ALTER TABLE "calendar_events"
      ADD CONSTRAINT "calendar_events_organizationId_fkey"
      FOREIGN KEY ("organizationId") REFERENCES "organizations"("id")
      ON DELETE RESTRICT ON UPDATE CASCADE;
    RAISE NOTICE 'calendar_event_organization: vincolo creato.';
  ELSE
    RAISE NOTICE 'calendar_event_organization: vincolo gia presente.';
  END IF;
END $fk$;
