-- Metriche: allineamento dei nomi dei tipi.
-- Gli script di seed usavano nomi diversi da quelli del form, quindi lo storico
-- di quelle misure risultava vuoto nella scheda atleta.
--
--   agility_t_test  -> t_test
--   vo2max          -> vo2_max
--   bench_press_1rm -> 1rm_bench
--   squat_1rm       -> 1rm_squat
--   wingspan        -> wing_span
--
-- `hand_span` resta com'è: ora esiste anche nel form come "Apertura mano".
-- `standing_reach`, `body_fat`, `sprint_20m` e `vertical_jump` erano già allineati.
--
-- Cambia solo la colonna `type`: nessuna misurazione viene creata o eliminata,
-- e ogni UPDATE è reversibile invertendo i due valori.

UPDATE "metrics" SET "type" = 't_test'     WHERE "type" = 'agility_t_test';
UPDATE "metrics" SET "type" = 'vo2_max'    WHERE "type" = 'vo2max';
UPDATE "metrics" SET "type" = '1rm_bench'  WHERE "type" = 'bench_press_1rm';
UPDATE "metrics" SET "type" = '1rm_squat'  WHERE "type" = 'squat_1rm';
UPDATE "metrics" SET "type" = 'wing_span'  WHERE "type" = 'wingspan';
