/*
  Warnings:

  - A unique constraint covering the columns `[stripeCustomerId]` on the table `organizations` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "organizations" ADD COLUMN     "stripeCustomerId" TEXT,
ADD COLUMN     "stripeSubscriptionId" TEXT,
ADD COLUMN     "subscriptionEndsAt" TIMESTAMP(3),
ADD COLUMN     "subscriptionStatus" TEXT DEFAULT 'inactive',
ADD COLUMN     "subscriptionTier" TEXT DEFAULT 'free';

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "consentAnalytics" BOOLEAN DEFAULT false,
ADD COLUMN     "consentMarketing" BOOLEAN DEFAULT false,
ADD COLUMN     "consentThirdParty" BOOLEAN DEFAULT false,
ADD COLUMN     "consentUpdatedAt" TIMESTAMP(3);

-- CreateIndex
CREATE UNIQUE INDEX "organizations_stripeCustomerId_key" ON "organizations"("stripeCustomerId");
