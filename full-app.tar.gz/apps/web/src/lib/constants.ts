// ============================================
// TrainMind — Frontend Constants
// ============================================

export const APP_NAME = 'TrainMind';
export const APP_DESCRIPTION = 'Piattaforma AI per preparatori fisici nel basket';

export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
export const API_PREFIX = '/api/v1';

/**
 * URL dell'app dedicata agli atleti. Serve a reindirizzarli quando provano ad
 * accedere alla dashboard dei preparatori (vedi AuthGuard).
 * In produzione arriva dal build arg NEXT_PUBLIC_ATHLETE_APP_URL.
 */
export const ATHLETE_APP_URL =
  process.env.NEXT_PUBLIC_ATHLETE_APP_URL || 'http://localhost:3003';

/** Ruoli ammessi nella dashboard dei preparatori. ATHLETE è escluso di proposito. */
export const STAFF_ROLES = ['ADMIN', 'TRAINER', 'MEDICAL', 'VIEWER'] as const;

export const PAGINATION_DEFAULT_LIMIT = 20;
export const PAGINATION_MAX_LIMIT = 100;

export const POSITIONS = [
  'Point Guard',
  'Shooting Guard',
  'Small Forward',
  'Power Forward',
  'Center',
] as const;

export const RPE_SCALE = [
  { value: 1, label: '1 - Riposo', color: '#22C55E' },
  { value: 2, label: '2 - Molto leggero', color: '#22C55E' },
  { value: 3, label: '3 - Leggero', color: '#84CC16' },
  { value: 4, label: '4 - Moderato', color: '#84CC16' },
  { value: 5, label: '5 - Medio', color: '#F59E0B' },
  { value: 6, label: '6 - Medio-alto', color: '#F59E0B' },
  { value: 7, label: '7 - Alto', color: '#F97316' },
  { value: 8, label: '8 - Molto alto', color: '#EF4444' },
  { value: 9, label: '9 - Massimale', color: '#EF4444' },
  { value: 10, label: '10 - Estremo', color: '#DC2626' },
] as const;

export const EXERCISE_CATEGORIES = [
  'Forza',
  'Potenza',
  'Condizionamento-Metabolico',
  'Velocita',
  'Agilita',
  'Flessibilita',
  'Mobilita',
  'Release',
  'Propriocezione',
  'Core',
  'Pliometria',
  'Prevenzione',
  'Riabilitazione',
  'Basket-Specifico',
] as const;

/**
 * Categorie in cui il carico di base e' il peso corporeo dell'atleta.
 *
 * Per queste il campo "Kg" non e' il carico: e' il **sovraccarico** aggiunto al
 * corpo libero. Scriverci 0 o lasciarlo vuoto significa BW puro, non "nessun
 * carico". Cambia l'etichetta, non il dato: resta `sessionExercise.weight`.
 */
export const BODYWEIGHT_CATEGORIES = new Set<string>(['Pliometria']);

export function isBodyweightCategory(category?: string | null): boolean {
  return !!category && BODYWEIGHT_CATEGORIES.has(category);
}

export const WELLNESS_FIELDS = [
  { key: 'sleepHours', label: 'Ore Sonno', min: 0, max: 14, unit: 'h' },
  { key: 'sleepQuality', label: 'Qualità Sonno', min: 1, max: 5 },
  { key: 'fatigue', label: 'Fatica', min: 1, max: 5 },
  { key: 'soreness', label: 'Dolore Muscolare', min: 1, max: 5 },
  { key: 'stress', label: 'Stress', min: 1, max: 5 },
  { key: 'mood', label: 'Umore', min: 1, max: 5 },
] as const;
