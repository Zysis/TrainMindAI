"""TrainMind AI Service Package."""
