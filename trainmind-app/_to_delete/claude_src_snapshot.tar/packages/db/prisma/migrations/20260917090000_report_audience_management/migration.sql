-- Report: nuovo destinatario "Dirigenza" e fine del report "Preparatore".
--
-- 1. Il valore MANAGEMENT entra nell'enum. ADD VALUE non puo' essere usato
--    nella stessa transazione che lo crea, ma qui non lo usiamo: nessun
--    problema anche se il file viene eseguito in un blocco unico.
-- 2. Le schedulazioni "Preparatore" diventano "Staff tecnico", che da oggi
--    contiene anche aderenza, pianificato vs reale e adattamenti.
--    TRAINER resta nell'enum ma non e' piu' usato (vedi schema.prisma).
--
-- Idempotente: si puo' rilanciare.

ALTER TYPE "ReportAudience" ADD VALUE IF NOT EXISTS 'MANAGEMENT';

UPDATE "report_schedules" SET "audience" = 'STAFF', "updatedAt" = NOW()
 WHERE "audience" = 'TRAINER';
