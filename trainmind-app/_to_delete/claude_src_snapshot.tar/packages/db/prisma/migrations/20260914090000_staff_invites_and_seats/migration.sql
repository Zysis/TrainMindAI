-- Inviti allo staff e posti per organizzazione.
--
-- Fino a ieri in un'organizzazione esistente non ci si poteva entrare in
-- nessun modo: la registrazione crea sempre un'organizzazione nuova, e
-- l'unico invito previsto era quello agli atleti. Due preparatori della
-- stessa societa' finivano quindi in due tenant separati, senza calendario
-- in comune. Da qui l'invito allo staff — che e' anche la ragione per cui
-- scrivere il nome di una societa' altrui non da' accesso a niente.

-- ─── Posti acquistati oltre la quota del piano ───────────────────────────
-- La quota inclusa sta nel codice (starter 1, professional 2, ultra 4);
-- questa colonna conta solo gli extra, ognuno al prezzo di uno Starter.
ALTER TABLE "organizations" ADD COLUMN "extraSeats" INTEGER NOT NULL DEFAULT 0;

-- ─── Inviti allo staff ───────────────────────────────────────────────────
CREATE TABLE "staff_invites" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "role" "UserRole" NOT NULL DEFAULT 'TRAINER',
    "token" TEXT NOT NULL,
    "status" "InviteStatus" NOT NULL DEFAULT 'PENDING',
    "invitedById" TEXT NOT NULL,
    "organizationId" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "acceptedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "staff_invites_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "staff_invites_token_key" ON "staff_invites"("token");
CREATE INDEX "staff_invites_token_idx" ON "staff_invites"("token");
CREATE INDEX "staff_invites_email_idx" ON "staff_invites"("email");
CREATE INDEX "staff_invites_organizationId_status_idx" ON "staff_invites"("organizationId", "status");

ALTER TABLE "staff_invites" ADD CONSTRAINT "staff_invites_invitedById_fkey"
    FOREIGN KEY ("invitedById") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "staff_invites" ADD CONSTRAINT "staff_invites_organizationId_fkey"
    FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
