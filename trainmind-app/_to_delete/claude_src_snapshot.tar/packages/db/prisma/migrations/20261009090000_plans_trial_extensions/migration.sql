-- ============================================================
-- Piani nuovi, prova gratuita ed estensioni (9 ottobre 2026)
--
-- Strategia: marketing/Strategia_commerciale_basket_v3.docx
-- Regole nel codice: apps/api/src/lib/plans.ts
--
-- Tutto additivo e idempotente: si puo' rilanciare senza danni.
-- NON sostituire questo file con `prisma db push`: la colonna
-- planLegacy deve valere TRUE per le organizzazioni gia' esistenti
-- (esenti dai limiti nuovi) e FALSE per quelle che nasceranno.
-- db push la creerebbe FALSE per tutti.
-- ============================================================

-- 1) Offerta Club: nuovo valore dell'enum dei piani.
--    ADD VALUE non puo' stare in una transazione insieme a un uso del
--    valore stesso: qui non viene usato, quindi e' sicuro.
ALTER TYPE "OrganizationTier" ADD VALUE IF NOT EXISTS 'CLUB';

-- 2) Stato del piano sull'organizzazione.
--    planLegacy nasce TRUE (le righe di oggi diventano "storiche"),
--    poi il default passa a FALSE per le registrazioni future.
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "planLegacy" BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE "organizations" ALTER COLUMN "planLegacy" SET DEFAULT false;

ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "trialEndsAt" TIMESTAMP(3);
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "intendedTier" "OrganizationTier";
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "billingCycle" VARCHAR(10);
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "extraTeams" INTEGER NOT NULL DEFAULT 0;

-- 3) Pacchetti di atleti aggiuntivi, per squadra.
ALTER TABLE "teams" ADD COLUMN IF NOT EXISTS "extraAthletePacks" INTEGER NOT NULL DEFAULT 0;

-- 4) Registro delle riattivazioni degli atleti archiviati.
CREATE TABLE IF NOT EXISTS "athlete_reactivations" (
    "id" TEXT NOT NULL,
    "organizationId" TEXT NOT NULL,
    "athleteId" TEXT NOT NULL,
    "userId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "athlete_reactivations_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "athlete_reactivations_organizationId_createdAt_idx"
    ON "athlete_reactivations"("organizationId", "createdAt");

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'athlete_reactivations_organizationId_fkey') THEN
        ALTER TABLE "athlete_reactivations" ADD CONSTRAINT "athlete_reactivations_organizationId_fkey"
            FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'athlete_reactivations_athleteId_fkey') THEN
        ALTER TABLE "athlete_reactivations" ADD CONSTRAINT "athlete_reactivations_athleteId_fkey"
            FOREIGN KEY ("athleteId") REFERENCES "athletes"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
END $$;

-- 5) Console: le colonne nuove di organizations si vedono gia' (la SELECT e'
--    sulla tabella); la tabella nuova no, ma alla console serve solo il conteggio.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'trainmind_reporting') THEN
        GRANT SELECT ON TABLE "athlete_reactivations" TO "trainmind_reporting";
    END IF;
END $$;
