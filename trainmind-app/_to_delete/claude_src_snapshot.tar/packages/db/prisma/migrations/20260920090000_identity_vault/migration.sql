-- ============================================================
-- Caveau delle identita' — atleti e staff
-- ============================================================
--
-- Sposta gli identificatori diretti fuori dalle tabelle a cui sono agganciati
-- i dati di allenamento e sanitari. Nessuna riga viene cancellata: le colonne
-- vengono svuotate SOLO dopo che i valori sono stati copiati e ricontati.
--
-- Vedi documentation/PIANO_SEPARAZIONE_IDENTITA.md
--
-- Scritta per essere rilanciabile: ogni passo controlla il proprio stato, cosi'
-- una ripetizione dopo un'interruzione non fa danni.
--
-- ATTENZIONE: `reporting-role.sql` contiene una ALTER DEFAULT PRIVILEGES che
-- rende leggibile al ruolo reporting OGNI tabella nuova. La REVOKE in fondo non
-- e' un di piu': senza, `athlete_identities` nasce gia' visibile alla console.

-- ─── 1. Tabelle ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "athlete_identities" (
    "athleteId"   TEXT NOT NULL,
    "firstName"   TEXT NOT NULL,
    "lastName"    TEXT NOT NULL,
    "dateOfBirth" TIMESTAMP(3) NOT NULL,
    "email"       TEXT,
    "photoUrl"    TEXT,
    CONSTRAINT "athlete_identities_pkey" PRIMARY KEY ("athleteId")
);

CREATE TABLE IF NOT EXISTS "user_identities" (
    "userId"    TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName"  TEXT NOT NULL,
    CONSTRAINT "user_identities_pkey" PRIMARY KEY ("userId")
);

CREATE INDEX IF NOT EXISTS "athlete_identities_lastName_firstName_idx"
    ON "athlete_identities"("lastName", "firstName");
CREATE INDEX IF NOT EXISTS "user_identities_lastName_firstName_idx"
    ON "user_identities"("lastName", "firstName");

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'athlete_identities_athleteId_fkey') THEN
        ALTER TABLE "athlete_identities"
            ADD CONSTRAINT "athlete_identities_athleteId_fkey"
            FOREIGN KEY ("athleteId") REFERENCES "athletes"("id")
            ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'user_identities_userId_fkey') THEN
        ALTER TABLE "user_identities"
            ADD CONSTRAINT "user_identities_userId_fkey"
            FOREIGN KEY ("userId") REFERENCES "users"("id")
            ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
END $$;

-- ─── 2. Copia delle anagrafiche esistenti ───────────────────

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'athletes' AND column_name = 'firstName'
    ) THEN
        INSERT INTO "athlete_identities" ("athleteId", "firstName", "lastName", "dateOfBirth", "email", "photoUrl")
        SELECT a."id", a."firstName", a."lastName", a."dateOfBirth", a."email", a."photoUrl"
        FROM "athletes" a
        ON CONFLICT ("athleteId") DO NOTHING;
    END IF;

    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'users' AND column_name = 'firstName'
    ) THEN
        INSERT INTO "user_identities" ("userId", "firstName", "lastName")
        SELECT u."id", u."firstName", u."lastName"
        FROM "users" u
        ON CONFLICT ("userId") DO NOTHING;
    END IF;
END $$;

-- ─── 3. Anno di nascita sulla tabella atleti ────────────────

ALTER TABLE "athletes" ADD COLUMN IF NOT EXISTS "birthYear" INTEGER;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'athletes' AND column_name = 'dateOfBirth'
    ) THEN
        UPDATE "athletes" a
           SET "birthYear" = EXTRACT(YEAR FROM a."dateOfBirth")::int
         WHERE a."birthYear" IS NULL;
    ELSE
        UPDATE "athletes" a
           SET "birthYear" = EXTRACT(YEAR FROM i."dateOfBirth")::int
          FROM "athlete_identities" i
         WHERE i."athleteId" = a."id" AND a."birthYear" IS NULL;
    END IF;
END $$;

-- ─── 4. Controllo prima di toccare le colonne originali ─────
-- Se anche una sola anagrafica non e' arrivata nel caveau, la transazione
-- muore qui e le colonne restano dove sono.

DO $$
DECLARE
    orfani INT;
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'athletes' AND column_name = 'firstName'
    ) THEN
        SELECT count(*) INTO orfani
          FROM "athletes" a
          LEFT JOIN "athlete_identities" i ON i."athleteId" = a."id"
         WHERE i."athleteId" IS NULL;
        IF orfani > 0 THEN
            RAISE EXCEPTION 'STOP: % atleti senza identita copiata. Colonne NON rimosse.', orfani;
        END IF;
    END IF;

    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'users' AND column_name = 'firstName'
    ) THEN
        SELECT count(*) INTO orfani
          FROM "users" u
          LEFT JOIN "user_identities" i ON i."userId" = u."id"
         WHERE i."userId" IS NULL;
        IF orfani > 0 THEN
            RAISE EXCEPTION 'STOP: % utenti senza identita copiata. Colonne NON rimosse.', orfani;
        END IF;
    END IF;

    SELECT count(*) INTO orfani FROM "athletes" WHERE "birthYear" IS NULL;
    IF orfani > 0 THEN
        RAISE EXCEPTION 'STOP: % atleti senza anno di nascita.', orfani;
    END IF;
END $$;

ALTER TABLE "athletes" ALTER COLUMN "birthYear" SET NOT NULL;

-- ─── 5. Rimozione degli identificatori dalle tabelle dati ───

ALTER TABLE "athletes"
    DROP COLUMN IF EXISTS "firstName",
    DROP COLUMN IF EXISTS "lastName",
    DROP COLUMN IF EXISTS "dateOfBirth",
    DROP COLUMN IF EXISTS "email",
    DROP COLUMN IF EXISTS "photoUrl";

-- `users.email` NON si tocca: e' la credenziale di accesso.
ALTER TABLE "users"
    DROP COLUMN IF EXISTS "firstName",
    DROP COLUMN IF EXISTS "lastName";

-- ─── 6. Permessi ────────────────────────────────────────────

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'trainmind_reporting') THEN
        -- Gli atleti sono dei clienti, non nostri: la console non li vede.
        REVOKE ALL ON TABLE "athlete_identities" FROM "trainmind_reporting";
        -- Lo staff sono i clienti di LAB21: la lista contatti marketing serve.
        GRANT SELECT ON TABLE "user_identities" TO "trainmind_reporting";
    END IF;
END $$;

-- ─── 7. Traccia ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "_trainmind_data_migrations" (
    "name"       TEXT PRIMARY KEY,
    "applied_at" TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO "_trainmind_data_migrations" ("name")
VALUES ('20260920090000_identity_vault')
ON CONFLICT ("name") DO NOTHING;
