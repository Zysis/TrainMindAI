-- Provenienza dell'iscrizione: da dove arriva ogni societa' che si registra.
--
-- Tutte le colonne sono NULLABLE e senza default: le righe gia' presenti non
-- vengono toccate e restano a NULL. Non e' una lacuna da colmare, e' un fatto:
-- per gli account creati prima di oggi la sorgente non e' mai stata osservata
-- e non e' ricostruibile in nessun modo.
--
-- Sicura da lanciare su un database vivo: ADD COLUMN di una colonna nullable
-- senza default non riscrive la tabella, prende un lock brevissimo.

ALTER TABLE "organizations" ADD COLUMN "utmSource"         VARCHAR(120);
ALTER TABLE "organizations" ADD COLUMN "utmMedium"         VARCHAR(120);
ALTER TABLE "organizations" ADD COLUMN "utmCampaign"       VARCHAR(200);
ALTER TABLE "organizations" ADD COLUMN "signupReferrer"    VARCHAR(500);
ALTER TABLE "organizations" ADD COLUMN "signupAttribution" JSONB;

-- La console raggruppa per sorgente: senza indice sarebbe una scansione
-- completa a ogni caricamento della pagina Acquisizione.
CREATE INDEX "organizations_utmSource_idx" ON "organizations"("utmSource");
