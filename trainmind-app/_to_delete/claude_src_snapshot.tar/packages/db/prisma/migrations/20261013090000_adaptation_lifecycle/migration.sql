-- ============================================================
-- Ciclo di vita degli adattamenti AI (13 ottobre 2026)
--
-- Regole nel codice: apps/api/src/routes/adaptations.ts
--
-- Tutto additivo e idempotente: si puo' rilanciare senza danni.
-- Va lanciato con psql (contiene un backfill: db push lo ignorerebbe).
-- ============================================================

-- 1) Le proposte di squadra non hanno piu' un atleta "ancora".
ALTER TABLE "plan_adaptations" ALTER COLUMN "athleteId" DROP NOT NULL;
ALTER TABLE "plan_adaptations" ADD COLUMN IF NOT EXISTS "teamId" TEXT;

-- 2) Cosa e' stato applicato davvero, ripristino, sostituzione.
ALTER TABLE "plan_adaptations" ADD COLUMN IF NOT EXISTS "appliedPlan" JSONB;
ALTER TABLE "plan_adaptations" ADD COLUMN IF NOT EXISTS "revertedAt" TIMESTAMP(3);
ALTER TABLE "plan_adaptations" ADD COLUMN IF NOT EXISTS "revertedById" TEXT;
ALTER TABLE "plan_adaptations" ADD COLUMN IF NOT EXISTS "supersededById" TEXT;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'plan_adaptations_teamId_fkey') THEN
    ALTER TABLE "plan_adaptations"
      ADD CONSTRAINT "plan_adaptations_teamId_fkey"
      FOREIGN KEY ("teamId") REFERENCES "teams"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "plan_adaptations_teamId_status_idx"
  ON "plan_adaptations"("teamId", "status");
CREATE INDEX IF NOT EXISTS "plan_adaptations_trainingSessionId_status_idx"
  ON "plan_adaptations"("trainingSessionId", "status");

-- 3) Backfill delle proposte di squadra: la squadra era solo dentro metrics.
UPDATE "plan_adaptations" pa
SET "teamId" = pa."metrics"->>'teamId'
WHERE pa."metrics"->>'mode' = 'team'
  AND pa."teamId" IS NULL
  AND EXISTS (SELECT 1 FROM "teams" t WHERE t."id" = pa."metrics"->>'teamId');

UPDATE "plan_adaptations"
SET "athleteId" = NULL
WHERE "metrics"->>'mode' = 'team'
  AND "athleteId" IS NOT NULL;

-- 4) Le APPROVED gia' applicate hanno scritto esattamente la proposta.
--    Le MODIFIED no: cosa e' stato scritto non e' mai stato salvato, restano
--    con appliedPlan NULL (l'interfaccia lo dice).
UPDATE "plan_adaptations"
SET "appliedPlan" = "proposedPlan"
WHERE "status" = 'APPROVED'
  AND "appliedAt" IS NOT NULL
  AND "appliedPlan" IS NULL;
