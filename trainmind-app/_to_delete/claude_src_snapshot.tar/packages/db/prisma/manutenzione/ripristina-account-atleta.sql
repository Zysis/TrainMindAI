\echo '=== ripristino: rimette l indirizzo personale sull account atleta ==='
--
-- Annulla rinomina-account-atleta.sql. Aggiornato il 21/09/2026: da quando
-- quel file tocca anche l'email della scheda anagrafica (passata su
-- "athlete_identities" con la migration 20260920090000_identity_vault),
-- qui va annullata anche quella, altrimenti il ripristino resta a meta'.

UPDATE "users"
SET email = 'pispi29@hotmail.it'
WHERE role = 'ATHLETE' AND email = 'nicola.bortolotti@example.com';

UPDATE "athlete_identities"
SET email = 'pispi29@hotmail.it'
WHERE email = 'nicola.bortolotti@example.com';

UPDATE "athlete_invites"
SET email = 'pispi29@hotmail.it'
WHERE email = 'nicola.bortolotti@example.com';

UPDATE "staff_invites"
SET email = 'pispi29@hotmail.it'
WHERE email = 'nicola.bortolotti@example.com';

SELECT id, email FROM "users" WHERE role = 'ATHLETE';
