\echo '=== rinomina-account-atleta, scritto 15/09, aggiornato 21/09 ==='
--
-- Perche': la scheda profilo dell'app atleta mostra l'email dell'ACCOUNT, non
-- quella della scheda anagrafica. L'account atleta della demo e' stato creato
-- con un indirizzo personale, che finirebbe nelle figure della guida in tre
-- lingue. Qui lo si porta sul dominio example.com come tutto il resto.
--
-- La password NON cambia: dopo questo si entra nell'app atleta con il nuovo
-- indirizzo e la stessa password di prima.
--
-- Aggiornato dopo la migration 20260920090000_identity_vault: l'email
-- dell'ACCOUNT resta su "users", quella della SCHEDA anagrafica e' passata
-- su "athlete_identities", e nome e cognome stanno sulle due tabelle del
-- vault. Le due email restano distinte: e' proprio il punto del file.

BEGIN;

\echo '--- prima ---'
SELECT u.id, u.email, iu."firstName", iu."lastName"
  FROM "users" u
  LEFT JOIN "user_identities" iu ON iu."userId" = u.id
 WHERE u.role = 'ATHLETE';

\echo '--- controllo: nessuno usa gia il nuovo indirizzo ---'
SELECT count(*) AS gia_esistente FROM "users"
WHERE email = 'nicola.bortolotti@example.com';

UPDATE "users"
SET email = 'nicola.bortolotti@example.com'
WHERE role = 'ATHLETE'
  AND email = 'pispi29@hotmail.it';

\echo '--- email sulla scheda anagrafica dell atleta (vault) ---'
UPDATE "athlete_identities"
SET email = 'nicola.bortolotti@example.com'
WHERE email = 'pispi29@hotmail.it';

\echo '--- inviti atleta con lo stesso indirizzo (ripuliti) ---'
SELECT id, email, status FROM "athlete_invites" WHERE email = 'pispi29@hotmail.it';

UPDATE "athlete_invites"
SET email = 'nicola.bortolotti@example.com'
WHERE email = 'pispi29@hotmail.it';

UPDATE "staff_invites"
SET email = 'nicola.bortolotti@example.com'
WHERE email = 'pispi29@hotmail.it';

\echo '--- dopo: nessun indirizzo fuori da example.com deve restare ---'
SELECT 'user' AS tipo, email FROM "users" WHERE email NOT LIKE '%@example.com'
UNION ALL SELECT 'athlete', email FROM "athlete_identities"
  WHERE email IS NOT NULL AND email NOT LIKE '%@example.com'
UNION ALL SELECT 'athlete_invite', email FROM "athlete_invites"
  WHERE email NOT LIKE '%@example.com'
UNION ALL SELECT 'staff_invite', email FROM "staff_invites"
  WHERE email NOT LIKE '%@example.com';

COMMIT;
