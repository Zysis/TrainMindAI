import type { FastifyInstance } from 'fastify';
import { aiChatSchema, aiCoachSchema, aiGenerateSchema, aiWellnessInsightSchema, aiRtpSuggestSchema } from '../schemas/ai.js';
import { requireMinRole } from '../middleware/rbac.js';
import { openAIGenerate, openAIChat, isOpenAIFallbackAvailable } from '../lib/openai-fallback.js';
import { getModelForOperation, getModelRouting } from '../lib/ai-models.js';
import { recordAiUsage, extractUsage, parseUsageFromSseChunk } from '../services/ai-usage.js';
import { fullName } from '../lib/identity.js';
import { createPseudonymizer, maskSelectedAthleteName } from '../lib/pseudonym.js';
import { buildAthleteContext } from '../lib/athlete-context.js';
import { assertAiAvailable, isPlanEnforcementEnabled, PlanLimitError, sendPlanError } from '../lib/plans.js';
import type { AiOperation } from '../lib/ai-models.js';

/**
 * Operazione AI di ogni rotta che chiama il modello, per il controllo del
 * piano: funzione inclusa e crediti del mese. Le rotte di sola lettura
 * (/ai/usage, /ai/health) non ci sono e non vengono toccate.
 */
const AI_ROUTE_OPERATION: Record<string, AiOperation> = {
  '/api/v1/ai/chat': 'CHAT',
  '/api/v1/ai/coach': 'COACH',
  '/api/v1/ai/generate': 'GENERATE',
  '/api/v1/ai/wellness-insights': 'WELLNESS',
  '/api/v1/ai/rtp-suggest': 'RTP',
};

/**
 * AI Service URL (Python FastAPI on port 3002)
 */
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:3004';

/** Timeout for AI service requests (60s default, longer for generate) */
const AI_TIMEOUT_MS = 60_000;
const AI_GENERATE_TIMEOUT_MS = 120_000;
const MAX_RETRIES = 2;
const RETRY_DELAY_MS = 2_000;

/**
 * Sleep helper for retry delay.
 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Proxy a request to the AI service with timeout and retry logic.
 *
 * Retry strategy:
 * - 5xx / timeout: retry up to MAX_RETRIES times with exponential backoff
 * - 4xx: no retry (client error)
 * - Connection refused: no retry on first attempt, fail immediately with helpful message
 */
async function proxyToAI(
  endpoint: string,
  body: unknown,
  options: { timeoutMs?: number } = {}
): Promise<Response> {
  const url = `${AI_SERVICE_URL}${endpoint}`;
  const timeout = options.timeoutMs || AI_TIMEOUT_MS;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(timeout),
      });

      // Don't retry client errors
      if (response.status >= 400 && response.status < 500) {
        return response;
      }

      // Retry server errors
      if (response.status >= 500 && attempt < MAX_RETRIES) {
        lastError = new Error(`AI service returned ${response.status}`);
        await sleep(RETRY_DELAY_MS * (attempt + 1));
        continue;
      }

      return response;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));

      // Connection refused — don't retry, service is down
      if (lastError.message.includes('ECONNREFUSED') || lastError.message.includes('fetch failed')) {
        throw new Error('AI_SERVICE_DOWN');
      }

      // Timeout — retry
      if (lastError.name === 'TimeoutError' || lastError.name === 'AbortError') {
        if (attempt < MAX_RETRIES) {
          await sleep(RETRY_DELAY_MS * (attempt + 1));
          continue;
        }
        throw new Error('AI_SERVICE_TIMEOUT');
      }

      // Other error — retry
      if (attempt < MAX_RETRIES) {
        await sleep(RETRY_DELAY_MS * (attempt + 1));
        continue;
      }

      throw lastError;
    }
  }

  throw lastError || new Error('AI_SERVICE_UNAVAILABLE');
}

/**
 * Map internal error codes to user-friendly messages.
 */
function aiErrorResponse(error: unknown) {
  const msg = error instanceof Error ? error.message : String(error);

  if (msg === 'AI_SERVICE_DOWN') {
    return {
      status: 503,
      body: {
        success: false,
        error: {
          code: 'AI_SERVICE_DOWN',
          message: 'Il servizio AI non è avviato. Avvia il servizio AI e riprova.',
          retryable: true,
        },
      },
    };
  }

  if (msg === 'AI_SERVICE_TIMEOUT') {
    return {
      status: 504,
      body: {
        success: false,
        error: {
          code: 'AI_SERVICE_TIMEOUT',
          message: 'Il servizio AI sta impiegando troppo tempo. Riprova con una domanda più semplice.',
          retryable: true,
        },
      },
    };
  }

  return {
    status: 503,
    body: {
      success: false,
      error: {
        code: 'AI_SERVICE_UNAVAILABLE',
        message: 'Servizio AI non raggiungibile. Riprova tra qualche secondo.',
        retryable: true,
      },
    },
  };
}

export async function aiRoutes(app: FastifyInstance) {
  // All AI routes require authentication
  app.addHook('preHandler', app.authenticate);

  // Piano: AI inclusa e crediti del mese non esauriti. Gira dopo
  // l'autenticazione (gli hook seguono l'ordine di registrazione) e non fa
  // niente a interruttore spento o per gli account storici.
  app.addHook('preHandler', async (request, reply) => {
    if (reply.sent || !isPlanEnforcementEnabled()) return;
    if (request.method !== 'POST') return;
    const operation = AI_ROUTE_OPERATION[request.routeOptions?.url ?? ''];
    if (!operation) return;
    try {
      await assertAiAvailable(app.prisma, request.user.organizationId, operation);
    } catch (err) {
      if (err instanceof PlanLimitError) return sendPlanError(reply, err);
      throw err;
    }
  });

  // ─── POST /ai/chat — Chat with RAG (streaming or not) ────
  app.post('/ai/chat', async (request, reply) => {
    const parsed = aiChatSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Input non valido',
          details: parsed.error.flatten().fieldErrors,
        },
      });
    }

    const { organizationId, userId } = request.user;

    // La risposta segue la lingua scelta nell'interfaccia. Vale prima quella
    // mandata dal client con la domanda: la colonna `locale` si aggiorna con
    // una chiamata separata, che puo' fallire o arrivare dopo, e finche' resta
    // indietro l'assistente risponde nella lingua sbagliata. Il database resta
    // come riserva per i client che non la mandano.
    let chatLanguage: 'it' | 'en' | 'es' | undefined = parsed.data.locale;
    if (!chatLanguage) {
      const chatRequester = await app.prisma.user.findUnique({
        where: { id: userId },
        select: { locale: true },
      });
      chatLanguage =
        chatRequester?.locale === 'en' || chatRequester?.locale === 'es'
          ? chatRequester.locale
          : 'it';
    }

    // Il contesto dell'atleta lo costruisce l'ai-service a partire da
    // `athlete_id`, e non contiene piu' il nome. Se il preparatore lo scrive
    // nella domanda, qui viene tolto: il modello ha comunque i dati giusti
    // davanti, e il nome non lascia l'infrastruttura.
    let chatPayload: Record<string, unknown> = parsed.data;
    if (parsed.data.athlete_id) {
      const [selected, athleteContext] = await Promise.all([
        app.prisma.athlete.findFirst({
          where: { id: parsed.data.athlete_id, organizationId },
          select: { identity: { select: { firstName: true, lastName: true } } },
        }),
        buildAthleteContext(app, parsed.data.athlete_id, organizationId),
      ]);
      // Una riga per capire, dai log, se il contesto e' partito davvero: e'
      // la domanda che ci si fa ogni volta che l'AI risponde "non ho dati".
      request.log.info(
        { athleteId: parsed.data.athlete_id, contextChars: athleteContext?.length ?? 0 },
        'chat: contesto atleta',
      );

      chatPayload = {
        ...parsed.data,
        // Atleta di un'altra societa' (o inesistente): il contesto e' nullo e
        // l'id non deve proseguire verso l'ai-service, che altrimenti proverebbe
        // a recuperarlo per conto suo.
        ...(athleteContext ? { athlete_context: athleteContext } : { athlete_id: undefined }),
        ...(selected?.identity
          ? {
              messages: parsed.data.messages.map((m) =>
                m.role === 'user'
                  ? { ...m, content: maskSelectedAthleteName(m.content, selected.identity) }
                  : m,
              ),
            }
          : {}),
      };
    }

    const chatModel = getModelForOperation('CHAT');
    const startedAt = Date.now();

    try {
      const response = await proxyToAI('/ai/chat', {
        ...chatPayload,
        model: chatModel,
        language: chatLanguage,
      });

      if (!response.ok) {
        const errBody = await response.text();
        app.log.error({ status: response.status, body: errBody }, 'AI chat error');
        void recordAiUsage(app, {
          organizationId,
          userId,
          operation: 'CHAT',
          endpoint: '/ai/chat',
          requestedModel: chatModel,
          success: false,
          errorCode: `HTTP_${response.status}`,
          durationMs: Date.now() - startedAt,
        });
        return reply.status(response.status).send({
          success: false,
          error: { code: 'AI_SERVICE_ERROR', message: 'Errore dal servizio AI' },
        });
      }

      // Streaming: pipe the SSE response directly
      if (parsed.data.stream && response.body) {
        // reply.raw bypassa il plugin CORS di Fastify: gli header vanno messi a mano,
        // altrimenti il browser rifiuta lo stream ("Failed to fetch")
        const origin = request.headers.origin;
        reply.raw.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'X-Accel-Buffering': 'no',
          ...(origin
            ? { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin' }
            : {}),
        });

        // Mentre lo stream viene inoltrato al browser si intercetta l'evento
        // SSE `usage` emesso dall'ai-service: in streaming è l'unico modo
        // per conoscere i token consumati.
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let streamUsage: ReturnType<typeof parseUsageFromSseChunk> = null;
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (!streamUsage && value) {
              streamUsage = parseUsageFromSseChunk(
                decoder.decode(value, { stream: true }),
              );
            }
            reply.raw.write(value);
          }
        } finally {
          reader.releaseLock();
          reply.raw.end();
          void recordAiUsage(app, {
            organizationId,
            userId,
            operation: 'CHAT',
            endpoint: '/ai/chat',
            requestedModel: chatModel,
            usage: streamUsage,
            durationMs: Date.now() - startedAt,
          });
        }
        return;
      }

      // Non-streaming: return JSON
      const data = await response.json();
      void recordAiUsage(app, {
        organizationId,
        userId,
        operation: 'CHAT',
        endpoint: '/ai/chat',
        requestedModel: chatModel,
        usage: extractUsage(data),
        durationMs: Date.now() - startedAt,
      });
      return reply.send({ success: true, data });
    } catch (error) {
      // Fallback: call OpenAI directly if AI service is down (non-streaming only)
      const msg = error instanceof Error ? error.message : String(error);
      if ((msg === 'AI_SERVICE_DOWN' || msg === 'AI_SERVICE_TIMEOUT') && isOpenAIFallbackAvailable() && !parsed.data.stream) {
        app.log.info('AI service down — using OpenAI direct fallback for /ai/chat');
        try {
          const fallbackData = await openAIChat(parsed.data.messages, {
            temperature: parsed.data.temperature,
            max_tokens: parsed.data.max_tokens,
            model: chatModel,
          });
          void recordAiUsage(app, {
            organizationId,
            userId,
            operation: 'CHAT',
            endpoint: '/ai/chat[fallback]',
            requestedModel: chatModel,
            usage: extractUsage(fallbackData),
            durationMs: Date.now() - startedAt,
          });
          return reply.send({ success: true, data: fallbackData });
        } catch (fbErr) {
          app.log.error(fbErr, 'OpenAI chat fallback error');
        }
      }

      app.log.error(error, 'AI chat proxy error');
      void recordAiUsage(app, {
        organizationId,
        userId,
        operation: 'CHAT',
        endpoint: '/ai/chat',
        requestedModel: chatModel,
        success: false,
        errorCode: msg.slice(0, 60),
        durationMs: Date.now() - startedAt,
      });
      const errResp = aiErrorResponse(error);
      return reply.status(errResp.status).send(errResp.body);
    }
  });

  // ─── POST /ai/coach — Coach Q&A with RAG ─────────────────
  app.post('/ai/coach', async (request, reply) => {
    const parsed = aiCoachSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Input non valido',
          details: parsed.error.flatten().fieldErrors,
        },
      });
    }

    // Load user's exercise library for context
    const { organizationId } = request.user;
    let exerciseContext = '';
    try {
      const exercises = await app.prisma.exercise.findMany({
        where: { organizationId },
        select: { name: true, category: true, muscleGroups: true, equipment: true },
        orderBy: { category: 'asc' },
        take: 150,
      });
      if (exercises.length > 0) {
        const grouped: Record<string, string[]> = {};
        for (const ex of exercises) {
          if (!grouped[ex.category]) grouped[ex.category] = [];
          grouped[ex.category].push(ex.name);
        }
        const lines = Object.entries(grouped).map(
          ([cat, names]) => `${cat}: ${names.join(', ')}`
        );
        exerciseContext = `\n\nESERCIZI DISPONIBILI NELLA LIBRERIA DELL'UTENTE:\n${lines.join('\n')}\n\nQuando suggerisci esercizi, preferisci quelli già presenti nella libreria dell'utente. Se suggerisci esercizi non in lista, segnalalo.`;
      }
    } catch {
      // Non-critical
    }

    const { userId } = request.user;

    // La lingua della risposta segue la preferenza di interfaccia dell'utente.
    // Senza, l'assistente risponde sempre in italiano: i system prompt
    // dell'ai-service sono scritti in italiano e si chiudono con
    // "Rispondi sempre in italiano".
    const requester = await app.prisma.user.findUnique({
      where: { id: userId },
      select: { locale: true },
    });
    const language: 'it' | 'en' | 'es' =
      requester?.locale === 'en' || requester?.locale === 'es' ? requester.locale : 'it';

    // Come per la chat: se il nome dell'atleta selezionato compare nella
    // domanda, non parte insieme ad essa.
    let coachQuestion = parsed.data.question;
    let coachAthleteContext: string | null = null;
    let coachPayload: Record<string, unknown> = parsed.data;
    if (parsed.data.athlete_id) {
      const [selected, athleteContext] = await Promise.all([
        app.prisma.athlete.findFirst({
          where: { id: parsed.data.athlete_id, organizationId },
          select: { identity: { select: { firstName: true, lastName: true } } },
        }),
        buildAthleteContext(app, parsed.data.athlete_id, organizationId),
      ]);
      coachAthleteContext = athleteContext;
      // Stesso motivo della chat: senza contesto, l'id non viaggia.
      if (!athleteContext) coachPayload = { ...parsed.data, athlete_id: undefined };
      if (selected?.identity) {
        coachQuestion = maskSelectedAthleteName(coachQuestion, selected.identity);
      }
    }

    const coachModel = getModelForOperation('COACH');
    const startedAt = Date.now();

    try {
      const response = await proxyToAI('/ai/coach', {
        ...coachPayload,
        question: coachQuestion + exerciseContext,
        ...(coachAthleteContext ? { athlete_context: coachAthleteContext } : {}),
        model: coachModel,
        language,
      });

      if (!response.ok) {
        const errBody = await response.text();
        app.log.error({ status: response.status, body: errBody }, 'AI coach error');
        void recordAiUsage(app, {
          organizationId,
          userId,
          operation: 'COACH',
          endpoint: '/ai/coach',
          requestedModel: coachModel,
          success: false,
          errorCode: `HTTP_${response.status}`,
          durationMs: Date.now() - startedAt,
        });
        return reply.status(response.status).send({
          success: false,
          error: { code: 'AI_SERVICE_ERROR', message: 'Errore dal servizio AI' },
        });
      }

      const data = await response.json();
      void recordAiUsage(app, {
        organizationId,
        userId,
        operation: 'COACH',
        endpoint: '/ai/coach',
        requestedModel: coachModel,
        usage: extractUsage(data),
        durationMs: Date.now() - startedAt,
      });
      return reply.send({ success: true, data });
    } catch (error) {
      // Fallback: call OpenAI directly if AI service is down
      const msg = error instanceof Error ? error.message : String(error);
      if ((msg === 'AI_SERVICE_DOWN' || msg === 'AI_SERVICE_TIMEOUT') && isOpenAIFallbackAvailable()) {
        app.log.info('AI service down — using OpenAI direct fallback for /ai/coach');
        try {
          const fallbackInstruction =
            language === 'en'
              ? 'Reply in English.'
              : language === 'es'
                ? 'Responde en espanol.'
                : 'Rispondi in italiano.';
          const fallbackData = await openAIChat(
            [
              {
                role: 'user',
                content: `${fallbackInstruction}\n\n${parsed.data.question}${exerciseContext}`,
              },
            ],
            { model: coachModel },
          );
          void recordAiUsage(app, {
            organizationId,
            userId,
            operation: 'COACH',
            endpoint: '/ai/coach[fallback]',
            requestedModel: coachModel,
            usage: extractUsage(fallbackData),
            durationMs: Date.now() - startedAt,
          });
          return reply.send({ success: true, data: fallbackData });
        } catch (fbErr) {
          app.log.error(fbErr, 'OpenAI coach fallback error');
        }
      }

      app.log.error(error, 'AI coach proxy error');
      void recordAiUsage(app, {
        organizationId,
        userId,
        operation: 'COACH',
        endpoint: '/ai/coach',
        requestedModel: coachModel,
        success: false,
        errorCode: msg.slice(0, 60),
        durationMs: Date.now() - startedAt,
      });
      const errResp = aiErrorResponse(error);
      return reply.status(errResp.status).send(errResp.body);
    }
  });

  // ─── POST /ai/generate — Generate training content ────────
  app.post('/ai/generate', {
    preHandler: [requireMinRole('TRAINER')],
  }, async (request, reply) => {
    const parsed = aiGenerateSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Input non valido',
          details: parsed.error.flatten().fieldErrors,
        },
      });
    }

    const { organizationId, userId } = request.user;
    const generateModel = getModelForOperation('GENERATE');
    const startedAt = Date.now();

    try {
      const response = await proxyToAI(
        '/ai/generate',
        { ...parsed.data, model: generateModel },
        { timeoutMs: AI_GENERATE_TIMEOUT_MS },
      );

      if (!response.ok) {
        const errBody = await response.text();
        app.log.error({ status: response.status, body: errBody }, 'AI generate error');
        void recordAiUsage(app, {
          organizationId,
          userId,
          operation: 'GENERATE',
          endpoint: '/ai/generate',
          requestedModel: generateModel,
          success: false,
          errorCode: `HTTP_${response.status}`,
          durationMs: Date.now() - startedAt,
        });
        return reply.status(response.status).send({
          success: false,
          error: { code: 'AI_SERVICE_ERROR', message: 'Errore dal servizio AI' },
        });
      }

      const data = await response.json();
      void recordAiUsage(app, {
        organizationId,
        userId,
        operation: 'GENERATE',
        endpoint: '/ai/generate',
        requestedModel: generateModel,
        usage: extractUsage(data),
        durationMs: Date.now() - startedAt,
      });
      return reply.send({ success: true, data });
    } catch (error) {
      // Fallback: call OpenAI directly if AI service is down
      const msg = error instanceof Error ? error.message : String(error);
      if ((msg === 'AI_SERVICE_DOWN' || msg === 'AI_SERVICE_TIMEOUT') && isOpenAIFallbackAvailable()) {
        app.log.info('AI service down — using OpenAI direct fallback for /ai/generate');
        try {
          // Il tetto di token va con la lunghezza del piano: 4096 bastano per
          // due settimane, non per dodici, e una risposta tagliata a meta'
          // non e' JSON valido.
          const expectedWeeks = parsed.data.expected_weeks ?? 4;
          const fallbackData = await openAIGenerate(parsed.data.prompt, {
            model: generateModel,
            max_tokens: Math.min(16000, Math.max(4096, expectedWeeks * 1400)),
          });
          const producedWeeks = fallbackData.structured_plan?.weeks?.length ?? 0;
          if (producedWeeks > 0 && producedWeeks !== expectedWeeks) {
            app.log.warn(
              { expectedWeeks, producedWeeks },
              'AI generate: numero di settimane diverso da quello richiesto',
            );
          }
          void recordAiUsage(app, {
            organizationId,
            userId,
            operation: 'GENERATE',
            endpoint: '/ai/generate[fallback]',
            requestedModel: generateModel,
            usage: extractUsage(fallbackData),
            durationMs: Date.now() - startedAt,
          });
          return reply.send({ success: true, data: fallbackData });
        } catch (fbErr) {
          app.log.error(fbErr, 'OpenAI fallback error');
          // Il troncamento non e' un problema di chiave: dirlo cosi' manda
          // l'utente a controllare la cosa sbagliata.
          const fbMsg = fbErr instanceof Error ? fbErr.message : String(fbErr);
          if (fbMsg === 'AI_RESPONSE_TRUNCATED') {
            return reply.status(503).send({
              success: false,
              error: {
                code: 'AI_RESPONSE_TRUNCATED',
                message:
                  'Il piano generato e\' stato troncato: e\' troppo lungo per una sola risposta. Riprova, oppure chiedi meno settimane e unisci i blocchi.',
                retryable: true,
              },
            });
          }
          return reply.status(503).send({
            success: false,
            error: {
              code: 'AI_FALLBACK_ERROR',
              message: 'Errore nella generazione AI. Verifica la chiave OPENAI_API_KEY.',
              retryable: true,
            },
          });
        }
      }

      app.log.error(error, 'AI generate proxy error');
      void recordAiUsage(app, {
        organizationId,
        userId,
        operation: 'GENERATE',
        endpoint: '/ai/generate',
        requestedModel: generateModel,
        success: false,
        errorCode: msg.slice(0, 60),
        durationMs: Date.now() - startedAt,
      });
      const errResp = aiErrorResponse(error);
      return reply.status(errResp.status).send(errResp.body);
    }
  });

  // ─── POST /ai/wellness-insights — AI wellness analysis ────
  app.post('/ai/wellness-insights', async (request, reply) => {
    const parsed = aiWellnessInsightSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Input non valido',
          details: parsed.error.flatten().fieldErrors,
        },
      });
    }

    const { organizationId } = request.user;
    const { athlete_id, days } = parsed.data;

    try {
      // Fetch wellness data from DB
      const where: Record<string, unknown> = {};

      if (athlete_id) {
        // Verify athlete belongs to same org
        const athlete = await app.prisma.athlete.findFirst({
          where: { id: athlete_id, organizationId },
        });
        if (!athlete) {
          return reply.status(404).send({
            success: false,
            error: { code: 'NOT_FOUND', message: 'Atleta non trovato' },
          });
        }
        where.athleteId = athlete_id;
      } else {
        // All athletes in the organization
        where.athlete = { organizationId };
      }

      // Fetch recent wellness logs
      const sinceDate = new Date();
      sinceDate.setDate(sinceDate.getDate() - days);
      where.date = { gte: sinceDate };

      const wellnessLogs = await app.prisma.wellnessLog.findMany({
        where,
        include: { athlete: { select: { position: true, identity: { select: { firstName: true, lastName: true } } } } },
        orderBy: { date: 'desc' },
        take: 100,
      });

      if (wellnessLogs.length === 0) {
        return reply.send({
          success: true,
          data: {
            answer: 'Nessun dato wellness disponibile per il periodo selezionato.',
            sources: [],
            references: [],
          },
        });
      }

      // Build a summary for the AI coach.
      // I nomi non escono da qui: al modello vanno etichette (A1, A2, ...) e
      // la risposta viene ri-mappata sui nomi veri. Vedi lib/pseudonym.ts.
      const pseudo = createPseudonymizer();
      const summary = wellnessLogs.map((log: Record<string, unknown>) => {
        const athlete = log.athlete as
          | { id?: string; position: string; identity: { firstName: string; lastName: string } | null }
          | null;
        const name = athlete ? pseudo.label(athlete) : 'Sconosciuto';
        return `${name} (${(log.date as Date).toISOString().slice(0, 10)}): Sonno=${log.sleepQuality}/5, Fatica=${log.fatigue}/5, Dolore=${log.soreness}/5, Stress=${log.stress}/5, Umore=${log.mood}/5`;
      }).join('\n');

      // Su tutte e cinque le voci 5 è la condizione migliore e 1 la peggiore:
      // senza dirlo, il modello legge "Fatica=1" come poca fatica.
      const scaleNote =
        'Scala 1-5 su tutte le voci, dove 5 è sempre la condizione migliore e 1 la peggiore ' +
        '(Fatica 1 = molto affaticato, 5 = per niente affaticato; stessa logica per Dolore e Stress).';
      const question = athlete_id
        ? `Analizza i dati wellness di questo atleta degli ultimi ${days} giorni e fornisci raccomandazioni. ${scaleNote}\n\n${summary}`
        : `Analizza i dati wellness del team degli ultimi ${days} giorni. Identifica atleti a rischio e fornisci raccomandazioni. ${scaleNote}\n\n${summary}`;

      // Call AI coach with wellness data.
      // NB: riusa l'endpoint /ai/coach dell'ai-service, ma è un'operazione
      // distinta — il modello va quindi passato esplicitamente.
      const wellnessModel = getModelForOperation('WELLNESS');
      const startedAt = Date.now();
      const response = await proxyToAI('/ai/coach', {
        question,
        namespaces: ['protocols', 'references'],
        top_k: 3,
        model: wellnessModel,
      });

      if (!response.ok) {
        void recordAiUsage(app, {
          organizationId,
          userId: request.user.userId,
          operation: 'WELLNESS',
          endpoint: '/ai/wellness-insights',
          requestedModel: wellnessModel,
          success: false,
          errorCode: `HTTP_${response.status}`,
          durationMs: Date.now() - startedAt,
        });
        return reply.status(503).send({
          success: false,
          error: { code: 'AI_SERVICE_ERROR', message: 'Errore dal servizio AI' },
        });
      }

      const data = await response.json();
      // Il preparatore rilegge i nomi veri: la sostituzione avviene qui, dopo
      // che la risposta e' tornata.
      if (data && typeof data.answer === 'string') {
        data.answer = pseudo.restore(data.answer);
      }
      void recordAiUsage(app, {
        organizationId,
        userId: request.user.userId,
        operation: 'WELLNESS',
        endpoint: '/ai/wellness-insights',
        requestedModel: wellnessModel,
        usage: extractUsage(data),
        durationMs: Date.now() - startedAt,
      });
      return reply.send({ success: true, data });
    } catch (error) {
      app.log.error(error, 'AI wellness insights error');
      void recordAiUsage(app, {
        organizationId,
        userId: request.user.userId,
        operation: 'WELLNESS',
        endpoint: '/ai/wellness-insights',
        requestedModel: getModelForOperation('WELLNESS'),
        success: false,
        errorCode: (error instanceof Error ? error.message : String(error)).slice(0, 60),
      });
      const errResp = aiErrorResponse(error);
      return reply.status(errResp.status).send(errResp.body);
    }
  });

  // ─── POST /ai/rtp-suggest — RTP phase advancement advisor ──
  app.post('/ai/rtp-suggest', {
    preHandler: [requireMinRole('TRAINER')],
  }, async (request, reply) => {
    const parsed = aiRtpSuggestSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: 'Input non valido', details: parsed.error.flatten().fieldErrors },
      });
    }

    const { organizationId } = request.user;
    const { protocol_id } = parsed.data;

    let protocol;
    try {
      protocol = await app.prisma.rTPProtocol.findFirst({
        where: { id: protocol_id, athlete: { organizationId } },
        include: {
          injury: true,
          athlete: { select: { position: true, identity: { select: { firstName: true, lastName: true, dateOfBirth: true } } } },
          criteria: { orderBy: { phase: 'asc' } },
          phaseLogs: { orderBy: { createdAt: 'desc' }, take: 10 },
        },
      });
    } catch (dbErr) {
      app.log.error(dbErr, 'RTP suggest DB error');
      return reply.status(500).send({
        success: false,
        error: { code: 'DB_ERROR', message: 'Errore nel recupero del protocollo RTP' },
      });
    }

    if (!protocol) {
      return reply.status(404).send({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Protocollo RTP non trovato' },
      });
    }

    // Build structured context for AI
    const athlete = protocol.athlete;
    const injury = protocol.injury;
    const criteriaMet = protocol.criteria.filter((c: { isMet: boolean }) => c.isMet).length;
    const criteriaTotal = protocol.criteria.length;
    const currentPhaseCriteria = protocol.criteria.filter(
      (c: { phase: string; isMet: boolean; description: string }) => c.phase === protocol.currentPhase,
    );
    const metInPhase = currentPhaseCriteria.filter((c: { isMet: boolean }) => c.isMet).length;

    // Anche qui il nome resta dentro l'API: al modello va un'etichetta.
    const rtpPseudo = createPseudonymizer();

    const phaseNames: Record<string, string> = {
      PHASE_1: 'Fase 1 — Controllo dolore',
      PHASE_2: 'Fase 2 — Mobilità',
      PHASE_3: 'Fase 3 — Forza',
      PHASE_4: 'Fase 4 — Allenamento completo',
      PHASE_5: 'Fase 5 — Return-to-Sport',
      CLEARED: 'Cleared — Ritorno completo',
    };
    const currentPhaseName = phaseNames[protocol.currentPhase] || protocol.currentPhase;

    const protocolSummary = {
      currentPhase: protocol.currentPhase,
      metInPhase,
      totalInPhase: currentPhaseCriteria.length,
      criteriaMet,
      criteriaTotal,
    };

    const question = `Sei un esperto di Return-to-Play nel basket. Analizza questo protocollo RTP e fornisci:
1. VALUTAZIONE: Il protocollo è pronto per avanzare alla fase successiva? Perché sì/no?
2. ESERCIZI CONSIGLIATI: 3-5 esercizi specifici per la fase attuale, considerando il tipo di infortunio e la posizione dell'atleta.
3. RISCHI: Eventuali segnali di attenzione o rischi da monitorare.
4. TIMELINE STIMATA: Stima di quando l'atleta potrebbe essere pronto per la fase successiva.

DATI PROTOCOLLO:
- Atleta: ${rtpPseudo.label(athlete)} (${athlete.position})
- Infortunio: ${injury.type} — ${injury.location} (severità: ${injury.severity}/5)
- Data infortunio: ${injury.dateOccurred}
- Fase attuale: ${currentPhaseName} (${metInPhase}/${currentPhaseCriteria.length} criteri soddisfatti)
- Progresso totale: ${criteriaMet}/${criteriaTotal} criteri soddisfatti
- Criteri fase attuale:
${currentPhaseCriteria.map((c: { description: string; isMet: boolean }) => `  ${c.isMet ? '✅' : '❌'} ${c.description}`).join('\n')}
- Ultime transizioni:
${protocol.phaseLogs.slice(0, 5).map((l: { fromPhase: string; toPhase: string; reason: string | null; createdAt: Date }) => `  ${phaseNames[l.fromPhase] || l.fromPhase} → ${phaseNames[l.toPhase] || l.toPhase} (${l.reason || 'N/A'}) — ${new Date(l.createdAt).toLocaleDateString('it-IT')}`).join('\n')}

Rispondi in italiano, in modo strutturato e professionale.`;

    // Anche l'RTP passa per /ai/coach sull'ai-service, ma resta sul modello
    // completo: è ambito clinico e non si fanno compromessi sulla qualità.
    const rtpModel = getModelForOperation('RTP');
    const rtpStartedAt = Date.now();

    try {
      const response = await proxyToAI('/ai/coach', {
        question,
        namespaces: ['protocols', 'exercises', 'references'],
        top_k: 8,
        model: rtpModel,
      });

      if (!response.ok) {
        const errBody = await response.text();
        app.log.error({ status: response.status, body: errBody }, 'AI RTP suggest error');
        void recordAiUsage(app, {
          organizationId,
          userId: request.user.userId,
          operation: 'RTP',
          endpoint: '/ai/rtp-suggest',
          requestedModel: rtpModel,
          success: false,
          errorCode: `HTTP_${response.status}`,
          durationMs: Date.now() - rtpStartedAt,
        });
        return reply.status(response.status).send({
          success: false,
          error: { code: 'AI_SERVICE_ERROR', message: 'Errore dal servizio AI' },
        });
      }

      const data = await response.json();
      if (data && typeof data.answer === 'string') {
        data.answer = rtpPseudo.restore(data.answer);
      }
      void recordAiUsage(app, {
        organizationId,
        userId: request.user.userId,
        operation: 'RTP',
        endpoint: '/ai/rtp-suggest',
        requestedModel: rtpModel,
        usage: extractUsage(data),
        durationMs: Date.now() - rtpStartedAt,
      });
      return reply.send({
        success: true,
        data: {
          ...data,
          protocol_summary: protocolSummary,
        },
      });
    } catch (error) {
      // If AI service is down, generate a rule-based fallback suggestion
      const msg = error instanceof Error ? error.message : String(error);
      app.log.warn({ msg }, 'AI RTP suggest — service unavailable, using fallback');

      // Il ripiego è basato su regole, non chiama alcun modello: costo zero.
      void recordAiUsage(app, {
        organizationId,
        userId: request.user.userId,
        operation: 'RTP',
        endpoint: '/ai/rtp-suggest[rule-based]',
        requestedModel: rtpModel,
        success: false,
        errorCode: msg.slice(0, 60),
        durationMs: Date.now() - rtpStartedAt,
      });

      const allMet = metInPhase === currentPhaseCriteria.length && currentPhaseCriteria.length > 0;
      const unmetCriteria = currentPhaseCriteria
        .filter((c: { isMet: boolean; description: string }) => !c.isMet)
        .map((c: { description: string }) => c.description);

      let fallbackAnswer: string;
      if (allMet) {
        fallbackAnswer = `✅ VALUTAZIONE: Tutti i ${metInPhase} criteri della ${currentPhaseName} sono soddisfatti. L'atleta ${fullName(athlete)} è pronto per avanzare alla fase successiva.\n\n⚠️ NOTA: Suggerimento generato automaticamente (servizio AI non disponibile). Per un'analisi più approfondita, riprova quando il servizio AI è attivo.`;
      } else {
        fallbackAnswer = `📋 VALUTAZIONE: ${metInPhase}/${currentPhaseCriteria.length} criteri soddisfatti nella ${currentPhaseName}. L'atleta ${fullName(athlete)} non è ancora pronto per avanzare.\n\n❌ CRITERI DA COMPLETARE:\n${unmetCriteria.map((c: string) => `• ${c}`).join('\n')}\n\n⚠️ NOTA: Suggerimento generato automaticamente (servizio AI non disponibile). Per esercizi consigliati e analisi dettagliata, riprova quando il servizio AI è attivo.`;
      }

      return reply.send({
        success: true,
        data: {
          answer: fallbackAnswer,
          sources: [],
          protocol_summary: protocolSummary,
        },
      });
    }
  });

  // ─── GET /ai/usage — Consumo AI dell'organizzazione ───────
  // Serve a rispondere alla domanda "quanto mi costa questo cliente?".
  // I costi sono in USD, come li fattura OpenAI: così il totale è
  // confrontabile con la dashboard di fatturazione senza conversioni.
  app.get('/ai/usage', async (request, reply) => {
    const { organizationId } = request.user;
    const query = request.query as { days?: string };
    const days = Math.min(Math.max(parseInt(query.days ?? '30', 10) || 30, 1), 365);

    const since = new Date();
    since.setDate(since.getDate() - days);

    try {
      const [byOperation, totals] = await Promise.all([
        app.prisma.aiUsageLog.groupBy({
          by: ['operation', 'model'],
          where: { organizationId, createdAt: { gte: since } },
          _sum: {
            promptTokens: true,
            completionTokens: true,
            totalTokens: true,
            costUsd: true,
            creditsCharged: true,
          },
          _count: { _all: true },
        }),
        app.prisma.aiUsageLog.aggregate({
          where: { organizationId, createdAt: { gte: since } },
          _sum: { totalTokens: true, costUsd: true, creditsCharged: true },
          _count: { _all: true },
        }),
      ]);

      const errorCount = await app.prisma.aiUsageLog.count({
        where: { organizationId, createdAt: { gte: since }, success: false },
      });

      return reply.send({
        success: true,
        data: {
          periodDays: days,
          since: since.toISOString(),
          totals: {
            calls: totals._count._all,
            errors: errorCount,
            totalTokens: totals._sum.totalTokens ?? 0,
            costUsd: Number(totals._sum.costUsd ?? 0),
            credits: totals._sum.creditsCharged ?? 0,
          },
          byOperation: byOperation.map((row) => ({
            operation: row.operation,
            model: row.model,
            calls: row._count._all,
            promptTokens: row._sum.promptTokens ?? 0,
            completionTokens: row._sum.completionTokens ?? 0,
            totalTokens: row._sum.totalTokens ?? 0,
            costUsd: Number(row._sum.costUsd ?? 0),
            credits: row._sum.creditsCharged ?? 0,
          })),
          routing: getModelRouting(),
        },
      });
    } catch (error) {
      app.log.error(error, 'AI usage query error');
      return reply.status(500).send({
        success: false,
        error: { code: 'USAGE_QUERY_ERROR', message: 'Errore nel calcolo del consumo AI' },
      });
    }
  });

  // ─── GET /ai/health — AI service health check ─────────────
  app.get('/ai/health', async (_request, reply) => {
    try {
      const response = await fetch(`${AI_SERVICE_URL}/health`, {
        signal: AbortSignal.timeout(5000),
      });

      if (!response.ok) {
        return reply.status(503).send({
          success: false,
          error: { code: 'AI_SERVICE_UNHEALTHY', message: 'Servizio AI non sano' },
        });
      }

      const data = await response.json();
      return reply.send({ success: true, data });
    } catch (error) {
      return reply.status(503).send({
        success: false,
        error: { code: 'AI_SERVICE_UNAVAILABLE', message: 'Servizio AI non raggiungibile' },
      });
    }
  });
}
