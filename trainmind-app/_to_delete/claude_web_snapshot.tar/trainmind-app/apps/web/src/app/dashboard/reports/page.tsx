'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { FileText, Download, Eye, Loader2, CalendarClock, ClipboardList, Trophy, ChevronRight } from 'lucide-react';
import { useToast } from '@/components/ui/toast';
import { Select } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { apiFetch } from '@/lib/auth/fetch';
import { useApiError } from '@/lib/i18n/api-error';
import { getAccessToken } from '@/lib/auth/api';
import { API_BASE_URL, API_PREFIX } from '@/lib/constants';
import { useTeam } from '@/hooks/use-team';
import { FeatureGate } from '@/components/plan/feature-gate';

type Audience = 'STAFF' | 'MEDICAL' | 'MANAGEMENT';

/** Nome del file scaricato: uguale a quello che mette l'API */
const AUDIENCE_SLUG: Record<Audience, string> = {
  STAFF: 'staff-tecnico',
  MEDICAL: 'staff-medico',
  MANAGEMENT: 'dirigenza',
};
type Format = 'JSON' | 'PDF' | 'DOCX';

interface AthleteOption {
  id: string;
  firstName: string;
  lastName: string;
}

function todayMinusDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

interface ReportPreview {
  metadata: {
    audience: string;
    organizationName: string;
    periodFrom: string;
    periodTo: string;
    generatedAt: string;
    generatedBy: string;
    teamName?: string;
    athleteName?: string;
  };
  summary?: string;
  highlights?: string[];
  kpis?: Array<{ label: string; value: string | number; trend?: string }>;
}

/** Estrae il messaggio d'errore dell'API, che risponde `{ error: { message } }` */
async function readApiError(res: Response): Promise<string> {
  const text = await res.text();
  try {
    const parsed = JSON.parse(text) as { error?: { message?: string }; message?: string };
    return parsed.error?.message || parsed.message || text || `HTTP ${res.status}`;
  } catch {
    return text || `HTTP ${res.status}`;
  }
}

export default function ReportsPage() {
  const t = useTranslations('reports');
  // Le descrizioni delle due schede sono i sottotitoli delle pagine stesse
  const tGame = useTranslations('gameReport');
  const tDaily = useTranslations('dailyReport');
  const apiError = useApiError();

  const AUDIENCE_OPTIONS = [
    { value: 'STAFF', label: t('audienceStaff') },
    { value: 'MEDICAL', label: t('audienceMedical') },
    { value: 'MANAGEMENT', label: t('audienceManagement') },
  ];
  const audienceLabel = (value: string) =>
    AUDIENCE_OPTIONS.find((o) => o.value === value)?.label ?? value;
  const { toast } = useToast();
  const { teams } = useTeam();
  const [teamId, setTeamId] = useState<string>('');
  const [athleteId, setAthleteId] = useState<string>('');
  const [athletes, setAthletes] = useState<AthleteOption[]>([]);
  const [audience, setAudience] = useState<Audience>('STAFF');
  const [periodFrom, setPeriodFrom] = useState(todayMinusDays(30));
  const [periodTo, setPeriodTo] = useState(todayIso());
  const [includeAISummary, setIncludeAISummary] = useState(true);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState<Format | null>(null);
  const [preview, setPreview] = useState<ReportPreview | null>(null);
  const [rawJson, setRawJson] = useState<unknown>(null);

  // Elenco atleti, ristretto alla squadra scelta
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const params = new URLSearchParams({ limit: '100' });
        if (teamId) params.set('teamId', teamId);
        const res = await apiFetch<{ data: AthleteOption[] }>(`/athletes?${params}`);
        if (cancelled) return;
        const list = res.data || [];
        setAthletes(list);
        setAthleteId((prev) => (prev && !list.some((a) => a.id === prev) ? '' : prev));
      } catch {
        if (!cancelled) setAthletes([]);
      }
    };
    load();
    return () => { cancelled = true; };
  }, [teamId]);

  function requestBody(format: Format) {
    return JSON.stringify({
      audience,
      periodFrom,
      periodTo,
      format,
      // Per la dirigenza il commento è sempre incluso (lo impone anche l'API)
      includeAISummary: audience === 'MANAGEMENT' ? true : includeAISummary,
      ...(teamId ? { teamId } : {}),
      ...(athleteId ? { athleteId } : {}),
    });
  }

  async function handleGeneratePreview() {
    setLoading(true);
    setPreview(null);
    setRawJson(null);
    try {
      const res = await apiFetch<{ success: boolean; data: { report: ReportPreview } }>(
        '/ai/report',
        { method: 'POST', body: requestBody('JSON') },
      );
      setPreview(res.data.report);
      setRawJson(res.data.report);
      toast('success', t('toastPreviewGenerated'));
    } catch (err) {
      const message = apiError(err, t('toastUnknownError'));
      toast('error', `${t('toastError')}: ${message}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleDownload(format: 'PDF' | 'DOCX') {
    setDownloading(format);
    try {
      const token = getAccessToken();
      if (!token) {
        toast('error', t('toastSessionExpired'));
        return;
      }

      const res = await fetch(`${API_BASE_URL}${API_PREFIX}/ai/report`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: requestBody(format),
      });

      if (!res.ok) {
        throw new Error(await readApiError(res));
      }

      const blob = await res.blob();
      if (blob.size === 0) {
        throw new Error(t('toastEmptyFile'));
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const teamSlug = teamId
        ? `-${(teams.find((x) => x.id === teamId)?.name || 'team').toLowerCase().replace(/\s+/g, '_')}`
        : '';
      const athlete = athletes.find((x) => x.id === athleteId);
      const athleteSlug = athlete
        ? `-${`${athlete.lastName}_${athlete.firstName}`.toLowerCase().replace(/\s+/g, '_')}`
        : '';
      a.download = `report-${AUDIENCE_SLUG[audience]}${teamSlug}${athleteSlug}-${periodFrom}_${periodTo}.${format.toLowerCase()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast('success', t('toastDownloaded', { format }));
    } catch (err) {
      const message = apiError(err, t('toastDownloadError'));
      toast('error', `${t('toastError')} ${format}: ${message}`);
    } finally {
      setDownloading(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{t('title')}</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">{t('subtitle')}</p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/dashboard/reports/schedules"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
          >
            <CalendarClock className="h-4 w-4" />
            {t('schedules')}
          </Link>
        </div>
      </div>

      {/* ─── Report singoli: partita e giornata ───────── */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Link
          href="/dashboard/reports/game"
          className="group flex min-w-0 items-center gap-4 rounded-xl border border-purple-200 dark:border-purple-800 bg-purple-50 dark:bg-purple-900/20 p-5 transition hover:border-purple-400 hover:shadow-sm dark:hover:border-purple-600"
        >
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-purple-600 text-white">
            <Trophy className="h-6 w-6" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-base font-semibold text-purple-900 dark:text-purple-100">{t('gameReport')}</span>
            <span className="block text-sm text-purple-700 dark:text-purple-300">{tGame('subtitle')}</span>
          </span>
          <ChevronRight className="h-5 w-5 shrink-0 text-purple-400 transition group-hover:translate-x-0.5" />
        </Link>
        <Link
          href="/dashboard/reports/daily"
          className="group flex min-w-0 items-center gap-4 rounded-xl border border-teal-200 dark:border-teal-800 bg-teal-50 dark:bg-teal-900/20 p-5 transition hover:border-teal-400 hover:shadow-sm dark:hover:border-teal-600"
        >
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-teal-600 text-white">
            <ClipboardList className="h-6 w-6" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-base font-semibold text-teal-900 dark:text-teal-100">{t('dailyReport')}</span>
            <span className="block text-sm text-teal-700 dark:text-teal-300">{tDaily('subtitle')}</span>
          </span>
          <ChevronRight className="h-5 w-5 shrink-0 text-teal-400 transition group-hover:translate-x-0.5" />
        </Link>
      </div>

      {/* Nella prova gratuita il generatore non c'e': resta il report
          giornaliero di prova, raggiungibile dalla scheda qui sopra. */}
      <FeatureGate feature="reports">
      {/* ─── Form ─────────────────────────────────────── */}
      <div className="card space-y-4">
        <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
          <FileText className="h-5 w-5 text-teal-600" />
          {t('configureReport')}
        </h2>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <Select
            label={t('audience')}
            options={AUDIENCE_OPTIONS}
            value={audience}
            onChange={(e) => setAudience(e.target.value as Audience)}
          />
          <Select
            label={t('team')}
            options={[
              { value: '', label: t('allTeams') },
              ...teams.map((team) => ({ value: team.id, label: team.name })),
            ]}
            value={teamId}
            onChange={(e) => { setTeamId(e.target.value); setAthleteId(''); }}
          />
          <Select
            label={t('athlete')}
            options={[
              { value: '', label: t('wholeTeam') },
              ...athletes.map((a) => ({ value: a.id, label: `${a.lastName} ${a.firstName}` })),
            ]}
            value={athleteId}
            onChange={(e) => setAthleteId(e.target.value)}
          />
          <div className="hidden md:block" />
          <Input
            label={t('from')}
            type="date"
            value={periodFrom}
            onChange={(e) => setPeriodFrom(e.target.value)}
          />
          <Input
            label={t('to')}
            type="date"
            value={periodTo}
            onChange={(e) => setPeriodTo(e.target.value)}
          />
        </div>

        {athleteId && (
          <p className="text-xs text-slate-500 dark:text-slate-400">{t('athleteReportHint')}</p>
        )}
        {audience === 'MANAGEMENT' && (
          <p className="text-xs text-slate-500 dark:text-slate-400">{t('managementHint')}</p>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          {audience !== 'MANAGEMENT' && (
            <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={includeAISummary}
                onChange={(e) => setIncludeAISummary(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 dark:border-slate-600 text-teal-600 focus:ring-teal-500"
              />
              {t('includeAISummary')}
            </label>
          )}
          <div className="flex-1" />
          <button
            type="button"
            onClick={handleGeneratePreview}
            disabled={loading}
            className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />}
            {loading ? t('generating') : t('preview')}
          </button>
          <button
            type="button"
            onClick={() => handleDownload('PDF')}
            disabled={downloading !== null}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {downloading === 'PDF' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            {t('downloadPdf')}
          </button>
          <button
            type="button"
            onClick={() => handleDownload('DOCX')}
            disabled={downloading !== null}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {downloading === 'DOCX' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            {t('downloadDocx')}
          </button>
        </div>
      </div>

      {/* ─── Preview ──────────────────────────────────── */}
      {preview && (
        <div className="card space-y-4">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            {t('preview')}
            {preview.metadata.athleteName
              ? ` — ${preview.metadata.athleteName}`
              : preview.metadata.teamName
                ? ` — ${preview.metadata.teamName}`
                : ''}
          </h2>

          <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 p-4">
            <div className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
              <div>
                <p className="text-xs uppercase text-slate-500 dark:text-slate-400">{t('organization')}</p>
                <p className="font-medium text-slate-900 dark:text-white">{preview.metadata.organizationName}</p>
              </div>
              <div>
                <p className="text-xs uppercase text-slate-500 dark:text-slate-400">{t('audience')}</p>
                <p className="font-medium text-slate-900 dark:text-white">{audienceLabel(preview.metadata.audience)}</p>
              </div>
              {preview.metadata.teamName && (
                <div>
                  <p className="text-xs uppercase text-slate-500 dark:text-slate-400">{t('team')}</p>
                  <p className="font-medium text-slate-900 dark:text-white">{preview.metadata.teamName}</p>
                </div>
              )}
              {preview.metadata.athleteName && (
                <div>
                  <p className="text-xs uppercase text-slate-500 dark:text-slate-400">{t('athlete')}</p>
                  <p className="font-medium text-slate-900 dark:text-white">{preview.metadata.athleteName}</p>
                </div>
              )}
              <div>
                <p className="text-xs uppercase text-slate-500 dark:text-slate-400">{t('periodLabel')}</p>
                <p className="font-medium text-slate-900 dark:text-white">
                  {preview.metadata.periodFrom} → {preview.metadata.periodTo}
                </p>
              </div>
              <div>
                <p className="text-xs uppercase text-slate-500 dark:text-slate-400">{t('generatedBy')}</p>
                <p className="font-medium text-slate-900 dark:text-white">{preview.metadata.generatedBy}</p>
              </div>
            </div>
          </div>

          {preview.summary && (
            <div className="rounded-lg border-l-4 border-indigo-500 bg-indigo-50 p-4 dark:bg-indigo-900/20">
              <p className="text-xs font-semibold uppercase text-indigo-700 dark:text-indigo-300">
                {preview.metadata.audience === 'MANAGEMENT' ? t('managementSummary') : t('aiSummary')}
              </p>
              <p className="mt-1 whitespace-pre-line text-sm leading-relaxed text-slate-700 dark:text-slate-300">{preview.summary}</p>
              {preview.highlights && preview.highlights.length > 0 && (
                <>
                  <p className="mt-3 text-xs font-semibold uppercase text-indigo-700 dark:text-indigo-300">{t('keyPoints')}</p>
                  <ul className="mt-1 list-disc space-y-0.5 pl-5 text-sm text-slate-700 dark:text-slate-300">
                    {preview.highlights.map((h, i) => (
                      <li key={i}>{h}</li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          )}

          {preview.kpis && preview.kpis.length > 0 && (
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {preview.kpis.map((kpi, i) => (
                <div key={i} className="rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3">
                  <p className="text-xs text-slate-500 dark:text-slate-400">{kpi.label}</p>
                  <p className="text-lg font-semibold text-slate-900 dark:text-white">{kpi.value}</p>
                </div>
              ))}
            </div>
          )}

          <details className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
            <summary className="cursor-pointer px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300">
              {t('viewFullJson')}
            </summary>
            <pre className="max-h-96 overflow-auto px-4 py-2 text-xs text-slate-700 dark:text-slate-300">
              {JSON.stringify(rawJson, null, 2)}
            </pre>
          </details>
        </div>
      )}
      </FeatureGate>
    </div>
  );
}
