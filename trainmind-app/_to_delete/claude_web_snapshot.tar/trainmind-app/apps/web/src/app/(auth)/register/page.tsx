'use client';

import { Suspense, useEffect, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { readAttribution, useForwardedParams, withForwarded } from '@/lib/attribution';
import Link from 'next/link';
import { useTranslations } from 'next-intl';
import { useApiError } from '@/lib/i18n/api-error';
import { useAuth } from '@/hooks/use-auth';
import { useLocaleStore } from '@/lib/i18n/store';
import { AuthShell } from '@/components/auth/auth-shell';
import { fetchStaffInvite, type StaffInvitePreview } from '@/lib/auth/api';

/* ─────────────────────────────────────────────────────────
 * Strade selezionabili in registrazione (dal 9/10/2026).
 * Gli id coincidono con i valori accettati dall'API.
 *
 * Due strade separate: la prova gratuita (15 giorni, poi si
 * sceglie) oppure un piano comprato subito. Finche' Stripe non
 * e' collegato il piano viene assegnato come e' sempre successo.
 * Prezzi IVA inclusa; la fonte e' apps/api/src/lib/plans.ts.
 * ───────────────────────────────────────────────────────── */
type PaidPlanId = 'starter' | 'professional' | 'ultra' | 'club';
type PlanId = 'trial' | PaidPlanId;

const PLANS: Array<{ id: PaidPlanId; labelKey: string; price: number; offerKey: string }> = [
  { id: 'starter', labelKey: 'planStarter', price: 15, offerKey: 'planOfferIndividual' },
  { id: 'professional', labelKey: 'planProfessional', price: 30, offerKey: 'planOfferIndividual' },
  { id: 'ultra', labelKey: 'planUltra', price: 35, offerKey: 'planOfferIndividual' },
  { id: 'club', labelKey: 'planClub', price: 50, offerKey: 'planOfferClub' },
];

function isPaidPlanId(v: string | null): v is PaidPlanId {
  return v === 'starter' || v === 'professional' || v === 'ultra' || v === 'club';
}

/**
 * `useSearchParams` obbliga a un confine di Suspense in build statica:
 * il form vero sta nel componente interno, la pagina lo avvolge.
 */
export default function RegisterPage() {
  return (
    <Suspense fallback={null}>
      <RegisterForm />
    </Suspense>
  );
}

function RegisterForm() {
  const router = useRouter();
  const params = useSearchParams();
  const t = useTranslations('auth');
  const apiError = useApiError();
  const { register, registerStaff, isAuthenticated } = useAuth();
  const locale = useLocaleStore((s) => s.locale);

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [organizationName, setOrganizationName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');

  // Strada: preselezionata da ?plan= (arriva dalle card della landing),
  // ma resta modificabile qui. Senza parametro, o con ?plan=trial, si parte
  // dalla prova gratuita.
  const planFromUrl = params.get('plan');
  const [plan, setPlan] = useState<PlanId>(
    isPaidPlanId(planFromUrl) ? planFromUrl : 'trial',
  );
  // Chi arriva da una card della landing e poi sceglie la prova: quel piano
  // e' quello che la pagina Abbonamento gli proporra' a fine prova.
  const intendedPlan = plan === 'trial' && isPaidPlanId(planFromUrl) ? planFromUrl : undefined;

  // Provenienza dell'iscrizione, letta una volta sola: se la calcolassimo al
  // momento dell'invio, un utente che nel frattempo ha ripulito l'indirizzo
  // arriverebbe senza sorgente.
  const attribution = useMemo(() => readAttribution(params), [params]);

  // Token che apre il cancello quando le registrazioni pubbliche sono chiuse.
  // Serve solo a noi, durante i test in produzione: `/register?k=<token>`.
  const accessToken = params.get('k') ?? undefined;

  /* ─── Invito allo staff ──────────────────────────────────
     `/register?staff=<token>` significa: non stai creando una societa' tua,
     stai entrando in quella di chi ti ha invitato. Cambiano tre cose — niente
     nome organizzazione (arriva dal token), niente scelta del piano (lo paga
     gia' l'organizzazione) ed email non modificabile, perche' e' quella a cui
     l'invito e' stato spedito. Il resto del modulo, consensi compresi, resta
     identico: un invitato e' un utente come gli altri. */
  const staffToken = params.get('staff') ?? undefined;
  const [staffInvite, setStaffInvite] = useState<StaffInvitePreview | null>(null);
  const [inviteError, setInviteError] = useState('');
  const [inviteLoading, setInviteLoading] = useState(!!staffToken);

  useEffect(() => {
    if (!staffToken) return;
    let cancelled = false;
    fetchStaffInvite(staffToken)
      .then((data) => {
        if (cancelled) return;
        setStaffInvite(data);
        setEmail(data.email);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        // Passa dal traduttore come tutti gli altri errori: qui si mostrava
        // `err.message`, cioe' la frase italiana del backend, anche a chi
        // aveva la pagina in inglese o in spagnolo.
        setInviteError(apiError(err, t('registerError')));
      })
      .finally(() => {
        if (!cancelled) setInviteLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // `apiError` e' memoizzata su `t` (vedi la nota in lib/i18n/api-error.ts):
    // metterla fra le dipendenze non rifa' il fetch a ogni render.
  }, [staffToken, t, apiError]);

  // Serve al link verso l'accesso qui sotto: chi va a fare login e poi torna
  // indietro non deve perdere ne' la campagna ne' il token.
  const forwarded = useForwardedParams();

  // Nessun consenso pre-flaggato (conforme al principio del consenso libero).
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptPrivacy, setAcceptPrivacy] = useState(false);
  const [consentHealthData, setConsentHealthData] = useState(false);
  const [acceptMarketing, setAcceptMarketing] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Redirect if already authenticated
  if (isAuthenticated) {
    router.push('/dashboard');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password.length < 8) {
      setError(t('passwordMinLength'));
      return;
    }

    if (password !== confirmPassword) {
      setError(t('passwordMismatch'));
      return;
    }

    if (!acceptTerms || !acceptPrivacy) {
      setError(t('consentRequired'));
      return;
    }

    setIsSubmitting(true);

    try {
      if (staffToken && staffInvite) {
        await registerStaff({
          // L'organizzazione e il ruolo arrivano dal token, non da qui.
          token: staffToken,
          password,
          firstName,
          lastName,
          dateOfBirth,
          acceptTerms,
          acceptPrivacy,
          consentHealthData,
          acceptMarketing,
          uiLanguage: locale,
        });
        router.push('/dashboard');
        return;
      }

      await register({
        email,
        password,
        firstName,
        lastName,
        organizationName,
        dateOfBirth,
        plan,
        intendedPlan,
        acceptTerms,
        acceptPrivacy,
        consentHealthData,
        acceptMarketing,
        // La lingua scelta qui diventa la lingua di default dell'account.
        uiLanguage: locale,
        attribution,
        accessToken,
      });
      router.push('/dashboard');
    } catch (err) {
      setError(apiError(err, t('registerError')));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Invito non ancora letto, o link rotto: non ha senso mostrare il modulo.
  // Nel secondo caso il messaggio spiega cosa fare invece di lasciare
  // compilare tutto per poi rifiutare l'invio.
  if (staffToken && inviteLoading) {
    return (
      <AuthShell>
        <p className="text-sm text-slate-500">{t('staffInviteLoading')}</p>
      </AuthShell>
    );
  }

  if (staffToken && inviteError) {
    return (
      <AuthShell>
        <h2 className="mb-1 text-2xl font-bold text-slate-900">{t('staffInviteInvalidTitle')}</h2>
        <p className="mb-4 text-sm text-slate-500">{inviteError}</p>
        <p className="text-sm text-slate-500">{t('staffInviteInvalidHint')}</p>
      </AuthShell>
    );
  }

  return (
    <AuthShell wide>
      <h2 className="mb-1 text-2xl font-bold text-slate-900">
        {staffInvite ? t('staffInviteTitle') : t('createAccount')}
      </h2>
      <p className="mb-6 text-sm text-slate-500">
        {staffInvite
          ? t('staffInviteSubtitle', { organization: staffInvite.organizationName })
          : t('registerSubtitle')}
      </p>

      {error && (
        <div className="mb-4 rounded-lg border border-danger-500/20 bg-danger-50 px-4 py-3 text-sm text-danger-700">
          {error}
        </div>
      )}

      {/* Segnale visibile che il token del cancello e' arrivato fin qui.
          Senza, l'unico modo di scoprire che si e' perso per strada e'
          compilare tutto il modulo e vedersi rifiutare l'invio. */}
      {accessToken && (
        <div className="mb-4 rounded-lg border border-teal-600/20 bg-teal-50 px-4 py-3 text-sm text-teal-800">
          Accesso di prova attivo: questa registrazione passa anche a
          registrazioni chiuse.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Due colonne: i campi vanno a coppie, cosi' il modulo sta
            in una schermata sola. Sotto lg torna a colonna singola. */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="firstName" className="label mb-1.5 block">
              {t('firstName')}
            </label>
            <input
              id="firstName"
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder={t('firstNamePlaceholder')}
              className="input-field"
              required
              disabled={isSubmitting}
            />
          </div>

          <div>
            <label htmlFor="lastName" className="label mb-1.5 block">
              {t('lastName')}
            </label>
            <input
              id="lastName"
              type="text"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              placeholder={t('lastNamePlaceholder')}
              className="input-field"
              required
              disabled={isSubmitting}
            />
          </div>

          <div>
            <label htmlFor="dateOfBirth" className="label mb-1.5 block">
              {t('dateOfBirth')}
            </label>
            <input
              id="dateOfBirth"
              type="date"
              value={dateOfBirth}
              onChange={(e) => setDateOfBirth(e.target.value)}
              className="input-field"
              required
              disabled={isSubmitting}
            />
          </div>

          <div>
            <label htmlFor="email" className="label mb-1.5 block">
              {t('email')}
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t('emailPlaceholder')}
              className="input-field"
              required
              /* Su invito l'indirizzo e' quello a cui il link e' stato
                 spedito: lasciarlo modificabile permetterebbe di girare
                 l'invito a chiunque. */
              disabled={isSubmitting || !!staffInvite}
              readOnly={!!staffInvite}
            />
          </div>

          <div>
            <label htmlFor="password" className="label mb-1.5 block">
              {t('password')}
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t('passwordHint')}
              className="input-field"
              required
              minLength={8}
              disabled={isSubmitting}
            />
          </div>

          <div>
            <label htmlFor="confirmPassword" className="label mb-1.5 block">
              {t('confirmPassword')}
            </label>
            <input
              id="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder={t('confirmPasswordPlaceholder')}
              className="input-field"
              required
              minLength={8}
              disabled={isSubmitting}
            />
          </div>

          {/* Su invito il campo sparisce: l'organizzazione e' quella di chi
              ha invitato, e non e' una cosa che si scrive. E' anche la
              ragione per cui digitare il nome di una societa' altrui nella
              registrazione normale non da' accesso a niente — quel modulo
              crea sempre un'organizzazione nuova. */}
          {!staffInvite && (
            <div className="sm:col-span-2">
              <label htmlFor="organizationName" className="label mb-1.5 block">
                {t('organizationName')}
              </label>
              <input
                id="organizationName"
                type="text"
                value={organizationName}
                onChange={(e) => setOrganizationName(e.target.value)}
                placeholder={t('orgPlaceholder')}
                className="input-field"
                required
                disabled={isSubmitting}
              />
            </div>
          )}
        </div>

        {staffInvite && (
          <div className="rounded-lg border border-teal-600/20 bg-teal-50 px-4 py-3 text-sm text-teal-800">
            {t('staffInviteBanner', {
              organization: staffInvite.organizationName,
              role: t(`staffRole.${staffInvite.role}`),
            })}
          </div>
        )}

        {/* ─── Piano ─────────────────────────────────────────
            Controllo segmentato invece di una tendina: mostra le tre
            opzioni e i prezzi tutti insieme, senza aprire nulla.
            Sono radio veri, quindi restano navigabili da tastiera. */}
        {/* Niente scelta del piano su invito: l'abbonamento e' gia' quello
            dell'organizzazione, e il posto l'ha gia' pagato chi invita. */}
        <fieldset disabled={isSubmitting} className={staffInvite ? 'hidden' : undefined}>
          <legend className="label mb-1.5 block">{t('planLabel')}</legend>

          {/* Prova gratuita: la strada di default, a tutta larghezza. */}
          <label
            className={`mb-2 flex cursor-pointer items-center justify-between gap-3 rounded-lg border px-3 py-2.5 transition-colors ${
              plan === 'trial'
                ? 'border-teal-600 bg-teal-50 ring-1 ring-teal-600'
                : 'border-slate-300 bg-white hover:border-slate-400'
            }`}
          >
            <input
              type="radio"
              name="plan"
              value="trial"
              checked={plan === 'trial'}
              onChange={() => setPlan('trial')}
              className="sr-only"
            />
            <span className="flex flex-col">
              <span className={`text-sm font-semibold ${plan === 'trial' ? 'text-teal-800' : 'text-slate-700'}`}>
                {t('planTrial')}
              </span>
              <span className={`text-xs ${plan === 'trial' ? 'text-teal-700' : 'text-slate-500'}`}>
                {t('planTrialHint')}
              </span>
            </span>
            <span className={`text-xs font-semibold ${plan === 'trial' ? 'text-teal-700' : 'text-slate-500'}`}>
              {t('planFree')}
            </span>
          </label>

          <p className="mb-1.5 mt-3 text-xs font-medium text-slate-500">{t('planOrBuy')}</p>
          <div className="grid grid-cols-2 gap-2">
            {PLANS.map((p) => {
              const active = plan === p.id;
              return (
                <label
                  key={p.id}
                  className={`flex cursor-pointer flex-col items-center rounded-lg border px-2 py-2.5 text-center transition-colors ${
                    active
                      ? 'border-teal-600 bg-teal-50 ring-1 ring-teal-600'
                      : 'border-slate-300 bg-white hover:border-slate-400'
                  }`}
                >
                  <input
                    type="radio"
                    name="plan"
                    value={p.id}
                    checked={active}
                    onChange={() => setPlan(p.id)}
                    className="sr-only"
                  />
                  <span className={`text-[0.6rem] font-semibold uppercase tracking-wider ${active ? 'text-teal-700' : 'text-slate-400'}`}>
                    {t(p.offerKey)}
                  </span>
                  <span
                    className={`text-sm font-semibold ${
                      active ? 'text-teal-800' : 'text-slate-700'
                    }`}
                  >
                    {t(p.labelKey)}
                  </span>
                  <span
                    className={`text-xs ${active ? 'text-teal-700' : 'text-slate-500'}`}
                  >
                    &euro;{p.price}
                    {t('planPerMonth')}
                  </span>
                </label>
              );
            })}
          </div>
          <p className="mt-1.5 text-xs text-slate-500">{t('planHint')}</p>
        </fieldset>

        {/* ─── CONSENSI: nessuna checkbox pre-flaggata ─── */}
        <div className="space-y-2.5 rounded-lg border border-slate-200 bg-slate-50 p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
            {t('consentsTitle')}
          </p>

          <label className="flex items-start gap-2 text-xs leading-relaxed text-slate-700">
            <input
              type="checkbox"
              checked={acceptTerms}
              onChange={(e) => setAcceptTerms(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-600"
              disabled={isSubmitting}
              required
            />
            <span>
              {t.rich('consentTerms', {
                link: (chunks) => (
                  <Link href="/terms" target="_blank" className="font-medium text-teal-700 underline">
                    {chunks}
                  </Link>
                ),
              })}{' '}
              <span className="text-danger-600">*</span>
            </span>
          </label>

          <label className="flex items-start gap-2 text-xs leading-relaxed text-slate-700">
            <input
              type="checkbox"
              checked={acceptPrivacy}
              onChange={(e) => setAcceptPrivacy(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-600"
              disabled={isSubmitting}
              required
            />
            <span>
              {t.rich('consentPrivacy', {
                link: (chunks) => (
                  <Link
                    href="/privacy"
                    target="_blank"
                    className="font-medium text-teal-700 underline"
                  >
                    {chunks}
                  </Link>
                ),
              })}{' '}
              <span className="text-danger-600">*</span>
            </span>
          </label>

          <label className="flex items-start gap-2 text-xs leading-relaxed text-slate-700">
            <input
              type="checkbox"
              checked={consentHealthData}
              onChange={(e) => setConsentHealthData(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-600"
              disabled={isSubmitting}
            />
            <span>
              {t.rich('consentHealth', {
                b: (chunks) => <strong>{chunks}</strong>,
              })}
            </span>
          </label>

          <label className="flex items-start gap-2 text-xs leading-relaxed text-slate-700">
            <input
              type="checkbox"
              checked={acceptMarketing}
              onChange={(e) => setAcceptMarketing(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-600"
              disabled={isSubmitting}
            />
            <span>{t('consentMarketing')}</span>
          </label>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-slate-500">
            <span className="text-danger-600">*</span> {t('requiredFields')}
            <span className="mx-2 text-slate-300">·</span>
            {t('dateOfBirthHint')}
          </p>
        </div>

        <button
          type="submit"
          disabled={isSubmitting || !acceptTerms || !acceptPrivacy}
          className="w-full rounded-lg bg-teal-700 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isSubmitting ? t('creating') : t('createAccount')}
        </button>
      </form>

      <p className="mt-4 text-center text-sm text-slate-500">
        {t('hasAccount')}{' '}
        <Link
          href={withForwarded('/login', forwarded)}
          className="font-medium text-teal-700 hover:text-teal-600"
        >
          {t('login')}
        </Link>
      </p>
    </AuthShell>
  );
}
